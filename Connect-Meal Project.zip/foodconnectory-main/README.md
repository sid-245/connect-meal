# 🍽️ Connect Meal — Where the extra food finds a purpose

> A platform that bridges surplus food from both large and small-scale contributors to those who truly need it.
![logo](https://github.com/Sneha-273/foodconnectory/blob/main/Screenshot_12-4-2025_222312_preview--foodconnectory.lovable.app.jpeg)
---

## ✨ Project Overview

**Connect Meal** is a **mission-driven platform** built to bridge the gap between those who have surplus food and those who need it the most. Whether it’s from a **grand event** or a **small family gathering**, the platform ensures that safe, hygienic food is shared — not wasted.

By supporting both **large-scale providers** (like hotels, caterers, and organizations) and **small-scale contributors** (such as households and individuals), Connect Meal creates a respectful, easy-to-use space to **give with purpose** and **receive with dignity**.

> 🥣 *Because no good meal deserves to be thrown away.*

---

## ✅ Features

- 🧭 Intuitive and clean user interface
- 👥 Role-based access: Donor, Supplier, Receiver
- 📝 Food donation form with live status tracking: `Pending → Requested → Approved`
- 📍 Pickup location tracking for clarity
- 🛡️ Built-in food safety guidelines
- 🏠 Supports both individual and large organization contributions
- 🔄 Smooth real-time experience with complete UI flow

---

## 🌍 Real-World Scenarios
- 🍽️ Post-wedding or large gathering food distribution
- 🏨 Hotel or restaurant food donation at day-end
- 🏠 Households with extra home-cooked meals


---

## 🔄 How It Works

```mermaid
graph TD;
    A[Register/Login] --> B[Choose Role: Donor / Supplier / Receiver];
    B --> C[Fill Donation Form];
    C --> D[Track Status: Pending → Requested → Completed];
    D --> E[Receiver views Pickup Location];
    E --> F[Receiver collects meal with safety instructions];
```
```mermaid
graph TD;
    A[Receiver Logs In] --> B[Views Available Donations];
    B --> C[Filters by Location or Quantity];
    C --> D[Requests a Donation];
    D --> E[Sees Pickup Location & Safety Info];
    E --> F[Picks Up the Food in Person];
    F --> G[Marks as Collected or Gives Feedback];
```
```mermaid
graph TD;
    A[NGO Team Registers or Logs In] --> B[Monitors Available Donations];
    B --> C[Requests Suitable Donations];
    C --> D[Contacts Donors if Needed];
    D --> E[Arranges Pickup at Donor Location];
    E --> F[Marks as Completed or Shares Feedback];
```
---
🚀 Tech Stack & Tools

🧱 Frontend
<p align="left"> <img src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white" /> <img src="https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black" /> <img src="https://img.shields.io/badge/TypeScript-3178C6?style=for-the-badge&logo=typescript&logoColor=white" /> <img src="https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB" /> </p>

🎨 UI & Styling
<p align="left"> <img src="https://img.shields.io/badge/TailwindCSS-06B6D4?style=for-the-badge&logo=tailwind-css&logoColor=white" /> <img src="https://img.shields.io/badge/shadcn/ui-000000?style=for-the-badge&logo=vercel&logoColor=white" /> </p>

⚙️ Development Tools
<p align="left"> <img src="https://img.shields.io/badge/Vite-646CFF?style=for-the-badge&logo=vite&logoColor=white" /> <img src="https://img.shields.io/badge/VS%20Code-007ACC?style=for-the-badge&logo=visual-studio-code&logoColor=white" /> </p> 

🗄️ Database  
<p align="left">
  <img src="https://img.shields.io/badge/Supabase-3ECF8E?style=for-the-badge&logo=supabase&logoColor=white" />
</p>


## 🌟 Features

- 🍱 Support for both small-scale and large-scale food donors
- 📍 Pickup location visible to receivers
- 🛡️ Safety instructions included for responsible handling
- 👥 Roles for Donor, Receiver, NGO/Food Bank Team
- 🧾 Smooth donation flow with clear tracking status
- 🧭 Minimal UI with guided navigation

## 📸 Screenshots

### 📝 Registration Page
Shows how new users can quickly register on the platform.
![Registration](./screenshots/registration.png)

### 🔐 Login Page
Simple login interface for all users.
![Login](https://github.com/Sneha-273/foodconnectory/blob/main/Create%20Account.png)

### 👤 Profile Page
Displays user information and allows basic settings.
![Profile](https://github.com/Sneha-273/foodconnectory/blob/main/Profile.png)

### 🖥️ Main Interface
User-friendly dashboard to access donation features.
![Interface](https://github.com/Sneha-273/foodconnectory/blob/main/Interface.png)

### 🧍 Receiver View
Shows how receivers view available donations and request meals.
![Receiver](https://github.com/Sneha-273/foodconnectory/blob/main/Welcome%20receiver%20page.png)

### 🔎 Filter Options  
Allows receivers to filter donations by location, quantity, or type.  
![Filter](https://github.com/Sneha-273/foodconnectory/blob/main/Receiver%20Side%20-%20filter.png)

### 📩 Donation Form  
Submit a new donation by providing a description, image, pickup location, and any important guidelines for safe handling.

![Request](https://github.com/Sneha-273/foodconnectory/blob/main/Donar%20Side.png)




## 🛠️ How to Run Locally

Follow these simple steps to set up the project on your local machine:

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/connect-meal.git
2. Navigate to the project directory
   ```bash
    cd connect-meal
4. Install dependencies
    ```bash
      npm install 
5. Start the development server
    ```bash
      npm run dev

✅ Make sure you have Node.js and npm installed on your system.

## 📌 About the Project

**Connect Meal: Where the Extra Food Finds a Purpose** — is a social impact platform designed to reduce food waste and feed the hungry. Whether you're an event organizer, hotel, restaurant, or an individual with extra hygienic food, this platform makes donation easy and accessible.

We aim to:
- Provide a **bridge between donors and receivers**
- Ensure **dignified and easy food collection**
- Support both **small-scale and large-scale** food donors
- Promote **safe handling** and timely distribution

## 🔮 Future Improvements

- 📦 Add food packaging guidelines based on quantity
- 📍 Real-time tracking for pickup progress (NGO-side)
- 🧾 Digital donation certificates for donors
- 📊 Admin dashboard for monitoring donations
- 📱 PWA support for mobile-first experience

