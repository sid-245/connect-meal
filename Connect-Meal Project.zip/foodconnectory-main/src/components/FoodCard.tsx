
import React from 'react';
import { Link } from 'react-router-dom';
import { FoodItem } from '@/types';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow } from 'date-fns';

interface FoodCardProps {
  food: FoodItem;
}

const FoodCard: React.FC<FoodCardProps> = ({ food }) => {
  const isExpiringSoon = new Date(food.expiryDate).getTime() - Date.now() < 24 * 60 * 60 * 1000;
  
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300">
      <Link to={`/food/${food.id}`}>
        <div className="relative h-48 overflow-hidden">
          {food.imageUrl ? (
            <img 
              src={food.imageUrl} 
              alt={food.title} 
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-connect-green-100 flex items-center justify-center">
              <span className="text-connect-green-500">No image available</span>
            </div>
          )}
          
          <div className="absolute top-2 right-2 flex flex-col gap-2">
            <Badge className={`
              ${food.status === 'available' ? 'bg-connect-green-500' : ''}
              ${food.status === 'reserved' ? 'bg-connect-orange-500' : ''}
              ${food.status === 'completed' ? 'bg-connect-light-500' : ''}
              ${food.status === 'expired' ? 'bg-red-500' : ''}
            `}>
              {food.status}
            </Badge>
            
            {isExpiringSoon && food.status === 'available' && (
              <Badge className="bg-connect-orange-500">
                Expiring Soon
              </Badge>
            )}
          </div>
        </div>
      </Link>
      
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <Link to={`/food/${food.id}`} className="block">
            <h3 className="text-lg font-semibold text-connect-light-900 hover:text-connect-green-600 transition-colors">
              {food.title}
            </h3>
          </Link>
        </div>
        
        <div className="text-sm text-connect-light-500 mb-3">
          <p>Posted {formatDistanceToNow(new Date(food.createdAt))} ago</p>
          <p>Expires in {formatDistanceToNow(new Date(food.expiryDate))}</p>
        </div>
        
        <div className="mb-3">
          <p className="text-connect-light-700 text-sm line-clamp-2">
            {food.description}
          </p>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="text-sm font-medium text-connect-green-600">
            {food.quantity}
          </span>
          
          <div className="text-sm text-connect-light-500">
            {food.location.address.split(',')[0]}
          </div>
        </div>
        
        {food.dietaryInfo && food.dietaryInfo.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-1">
            {food.dietaryInfo.slice(0, 2).map((info, index) => (
              <Badge key={index} variant="outline" className="bg-connect-light-50 text-connect-light-700 border-connect-light-200 text-xs">
                {info}
              </Badge>
            ))}
            {food.dietaryInfo.length > 2 && (
              <Badge variant="outline" className="bg-connect-light-50 text-connect-light-700 border-connect-light-200 text-xs">
                +{food.dietaryInfo.length - 2} more
              </Badge>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default FoodCard;
