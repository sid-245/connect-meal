
import React from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { FoodItem } from '@/types';
import { formatDistanceToNow } from 'date-fns';
import { MapPin, Clock, User, Tag, Thermometer } from 'lucide-react';

interface FoodDetailsModalProps {
  food: FoodItem | null;
  isOpen: boolean;
  onClose: () => void;
}

const FoodDetailsModal = ({ food, isOpen, onClose }: FoodDetailsModalProps) => {
  if (!food) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] z-50">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">{food.title}</DialogTitle>
          <DialogDescription>
            Donation by {food.donorName}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 mt-4">
          {food.imageUrl && (
            <div className="mb-4">
              <img 
                src={food.imageUrl} 
                alt={food.title} 
                className="w-full h-48 object-cover rounded-md"
              />
            </div>
          )}
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h3 className="font-medium text-sm text-gray-500 mb-1">Status</h3>
              <Badge className={`
                ${food.status === 'available' ? 'bg-green-100 text-green-800' : 
                food.status === 'reserved' ? 'bg-blue-100 text-blue-800' :
                food.status === 'completed' ? 'bg-gray-100 text-gray-800' :
                'bg-red-100 text-red-800'}
              `}>
                {food.status.charAt(0).toUpperCase() + food.status.slice(1)}
              </Badge>
            </div>
            
            <div>
              <h3 className="font-medium text-sm text-gray-500 mb-1">Quantity</h3>
              <p>{food.quantity}</p>
            </div>
          </div>
          
          <div>
            <h3 className="font-medium text-sm text-gray-500 mb-1">Description</h3>
            <p className="text-sm">{food.description}</p>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-connect-light-500" />
              <div>
                <h3 className="font-medium text-sm text-gray-500">Expiry Date</h3>
                <p className="text-sm">{new Date(food.expiryDate).toLocaleDateString()}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <User className="h-4 w-4 text-connect-light-500" />
              <div>
                <h3 className="font-medium text-sm text-gray-500">Posted</h3>
                <p className="text-sm">{formatDistanceToNow(new Date(food.createdAt))} ago</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-start gap-2">
            <MapPin className="h-4 w-4 text-connect-light-500 mt-1" />
            <div>
              <h3 className="font-medium text-sm text-gray-500">Pickup Location</h3>
              <p className="text-sm">{food.location.address}</p>
            </div>
          </div>
          
          {food.temperature && (
            <div className="flex items-center gap-2">
              <Thermometer className="h-4 w-4 text-connect-light-500" />
              <div>
                <h3 className="font-medium text-sm text-gray-500">Temperature</h3>
                <p className="text-sm capitalize">{food.temperature}</p>
              </div>
            </div>
          )}
          
          {food.categories && food.categories.length > 0 && (
            <div className="flex items-start gap-2">
              <Tag className="h-4 w-4 text-connect-light-500 mt-1" />
              <div>
                <h3 className="font-medium text-sm text-gray-500">Categories</h3>
                <div className="flex flex-wrap gap-1 mt-1">
                  {food.categories.map(category => (
                    <Badge key={category} variant="outline" className="text-xs">
                      {category}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          )}
          
          {food.dietaryInfo && food.dietaryInfo.length > 0 && (
            <div>
              <h3 className="font-medium text-sm text-gray-500 mb-1">Dietary Information</h3>
              <div className="flex flex-wrap gap-1">
                {food.dietaryInfo.map(info => (
                  <Badge key={info} variant="outline" className="text-xs bg-connect-green-50">
                    {info}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </div>
        
        <div className="flex justify-end gap-2 mt-4">
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default FoodDetailsModal;
