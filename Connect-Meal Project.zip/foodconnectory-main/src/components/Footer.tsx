
import React from 'react';
import { Link } from 'react-router-dom';
import Logo from './Logo';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-gray-200">
      <div className="connect-container py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center">
              <Logo />
              <span className="ml-2 text-xl font-bold text-connect-green-600">ConnectMeal</span>
            </div>
            <p className="mt-2 text-sm text-connect-light-600">
              Connecting surplus food with those who need it most.
            </p>
          </div>
          
          <div className="col-span-1">
            <h3 className="text-sm font-semibold text-connect-light-900 tracking-wider uppercase">Platform</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <Link to="/donate" className="text-sm text-connect-light-600 hover:text-connect-green-500">
                  Donate Food
                </Link>
              </li>
              <li>
                <Link to="/request" className="text-sm text-connect-light-600 hover:text-connect-green-500">
                  Request Food
                </Link>
              </li>
              <li>
                <Link to="/dashboard" className="text-sm text-connect-light-600 hover:text-connect-green-500">
                  Dashboard
                </Link>
              </li>
            </ul>
          </div>
          
          <div className="col-span-1">
            <h3 className="text-sm font-semibold text-connect-light-900 tracking-wider uppercase">Resources</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <a href="#" className="text-sm text-connect-light-600 hover:text-connect-green-500">
                  Food Safety Guidelines
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-connect-light-600 hover:text-connect-green-500">
                  FAQ
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-connect-light-600 hover:text-connect-green-500">
                  Blog
                </a>
              </li>
            </ul>
          </div>
          
          <div className="col-span-1">
            <h3 className="text-sm font-semibold text-connect-light-900 tracking-wider uppercase">Connect</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <a href="#" className="text-sm text-connect-light-600 hover:text-connect-green-500">
                  About Us
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-connect-light-600 hover:text-connect-green-500">
                  Contact
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-connect-light-600 hover:text-connect-green-500">
                  Partner with Us
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 border-t border-gray-200 pt-8 flex flex-col md:flex-row justify-between">
          <p className="text-sm text-connect-light-600">
            &copy; {new Date().getFullYear()} ConnectMeal. All rights reserved.
          </p>
          <div className="mt-4 md:mt-0 flex space-x-6">
            <a href="#" className="text-connect-light-500 hover:text-connect-green-500">
              Terms of Service
            </a>
            <a href="#" className="text-connect-light-500 hover:text-connect-green-500">
              Privacy Policy
            </a>
            <a href="#" className="text-connect-light-500 hover:text-connect-green-500">
              Cookie Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
