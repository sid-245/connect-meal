
import React from 'react';

const Logo: React.FC = () => {
  return (
    <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="36" height="36" rx="8" fill="#4CAF50" fillOpacity="0.1" />
      <path d="M18 8C12.48 8 8 12.48 8 18C8 23.52 12.48 28 18 28C23.52 28 28 23.52 28 18C28 12.48 23.52 8 18 8ZM13 21C11.9 21 11 20.1 11 19C11 17.9 11.9 17 13 17C14.1 17 15 17.9 15 19C15 20.1 14.1 21 13 21ZM18 21C16.9 21 16 20.1 16 19C16 17.9 16.9 17 18 17C19.1 17 20 17.9 20 19C20 20.1 19.1 21 18 21ZM23 21C21.9 21 21 20.1 21 19C21 17.9 21.9 17 23 17C24.1 17 25 17.9 25 19C25 20.1 24.1 21 23 21Z" fill="#4CAF50" />
    </svg>
  );
};

export default Logo;
