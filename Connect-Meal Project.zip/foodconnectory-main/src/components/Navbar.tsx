
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Menu, X } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import Logo from './Logo';

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { currentUser, logout } = useApp();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleLogout = () => {
    logout();
  };

  return (
    <nav className="bg-white border-b border-gray-200 shadow-sm">
      <div className="connect-container">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <Logo />
              <span className="ml-2 text-xl font-bold text-connect-green-600">ConnectMeal</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-4">
            <Link to="/" className="px-3 py-2 rounded-md text-sm font-medium text-connect-light-700 hover:text-connect-green-600">
              Home
            </Link>
            <Link to="/donate" className="px-3 py-2 rounded-md text-sm font-medium text-connect-light-700 hover:text-connect-green-600">
              Donate Food
            </Link>
            <Link to="/request" className="px-3 py-2 rounded-md text-sm font-medium text-connect-light-700 hover:text-connect-green-600">
              Request Food
            </Link>
            {currentUser ? (
              <>
                <Link to="/dashboard" className="px-3 py-2 rounded-md text-sm font-medium text-connect-light-700 hover:text-connect-green-600">
                  Dashboard
                </Link>
                <Link to="/profile" className="px-3 py-2 rounded-md text-sm font-medium text-connect-light-700 hover:text-connect-green-600">
                  Profile
                </Link>
                <Button onClick={handleLogout} variant="outline" className="ml-2">
                  Log Out
                </Button>
              </>
            ) : (
              <>
                <Link to="/login">
                  <Button variant="outline" className="ml-2">Log In</Button>
                </Link>
                <Link to="/register">
                  <Button className="bg-connect-green-500 hover:bg-connect-green-600 text-white">Sign Up</Button>
                </Link>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={toggleMenu}
              className="inline-flex items-center justify-center p-2 rounded-md text-connect-light-500 hover:text-connect-green-500 focus:outline-none"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              <Link 
                to="/" 
                className="block px-3 py-2 rounded-md text-base font-medium text-connect-light-700 hover:text-connect-green-600"
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
              <Link 
                to="/donate" 
                className="block px-3 py-2 rounded-md text-base font-medium text-connect-light-700 hover:text-connect-green-600"
                onClick={() => setIsMenuOpen(false)}
              >
                Donate Food
              </Link>
              <Link 
                to="/request" 
                className="block px-3 py-2 rounded-md text-base font-medium text-connect-light-700 hover:text-connect-green-600"
                onClick={() => setIsMenuOpen(false)}
              >
                Request Food
              </Link>
              {currentUser ? (
                <>
                  <Link 
                    to="/dashboard" 
                    className="block px-3 py-2 rounded-md text-base font-medium text-connect-light-700 hover:text-connect-green-600"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Dashboard
                  </Link>
                  <Link 
                    to="/profile" 
                    className="block px-3 py-2 rounded-md text-base font-medium text-connect-light-700 hover:text-connect-green-600"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Profile
                  </Link>
                  <Button 
                    onClick={() => {
                      handleLogout();
                      setIsMenuOpen(false);
                    }} 
                    variant="outline" 
                    className="w-full mt-2"
                  >
                    Log Out
                  </Button>
                </>
              ) : (
                <>
                  <Link 
                    to="/login" 
                    className="block w-full"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <Button variant="outline" className="w-full">Log In</Button>
                  </Link>
                  <Link 
                    to="/register" 
                    className="block w-full mt-2"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <Button className="w-full bg-connect-green-500 hover:bg-connect-green-600 text-white">Sign Up</Button>
                  </Link>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
