
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useApp } from '@/context/AppContext';
import { FoodItem } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { AlertCircle } from 'lucide-react';

interface RequestFoodButtonProps {
  food: FoodItem;
}

const RequestFoodButton = ({ food }: RequestFoodButtonProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [quantity, setQuantity] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { currentUser, requestFood, checkPhoneVerified } = useApp();
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentUser) {
      toast({
        title: 'Login required',
        description: 'Please log in to request food',
        variant: 'destructive',
      });
      navigate('/login');
      return;
    }
    
    if (!checkPhoneVerified()) {
      toast({
        title: 'Verification required',
        description: 'Please verify your phone number in your profile settings',
        variant: 'destructive',
      });
      setIsOpen(false);
      navigate('/profile');
      return;
    }
    
    if (!quantity) {
      toast({
        title: 'Quantity required',
        description: 'Please specify the quantity you need',
        variant: 'destructive',
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      requestFood({
        foodItemId: food.id,
        requesterId: currentUser.id,
        status: 'pending',
        quantity,
        message
      });
      
      toast({
        title: 'Request submitted',
        description: 'Your food request has been sent to the donor',
        variant: 'default',
      });
      
      setIsOpen(false);
      setQuantity('');
      setMessage('');
    } catch (error) {
      toast({
        title: 'Request failed',
        description: error instanceof Error ? error.message : 'Something went wrong',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  if (!currentUser || currentUser.role !== 'receiver') {
    return null;
  }
  
  const phoneVerified = checkPhoneVerified();
  
  return (
    <div className="relative z-10">
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button className="w-full bg-connect-green-500 hover:bg-connect-green-600 text-white relative z-10">
            Request Food
          </Button>
        </DialogTrigger>
        
        <DialogContent className="sm:max-w-[425px] z-50">
          {!phoneVerified ? (
            <div>
              <DialogHeader>
                <DialogTitle>Phone Verification Required</DialogTitle>
                <DialogDescription>
                  You need to verify your phone number before requesting food
                </DialogDescription>
              </DialogHeader>
              
              <div className="py-4">
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Verification Required</AlertTitle>
                  <AlertDescription>
                    For security reasons, we require phone verification before you can request food.
                  </AlertDescription>
                </Alert>
              </div>
              
              <DialogFooter>
                <Button 
                  onClick={() => {
                    setIsOpen(false);
                    navigate('/profile');
                  }}
                >
                  Go to Profile Settings
                </Button>
              </DialogFooter>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <DialogHeader>
                <DialogTitle>Request Food</DialogTitle>
                <DialogDescription>
                  Send a request to {food.donorName} for "{food.title}"
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="quantity" className="text-right">
                    Quantity
                  </Label>
                  <Input
                    id="quantity"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    placeholder={`Available: ${food.quantity}`}
                    className="col-span-3"
                    required
                  />
                </div>
                
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="message" className="text-right">
                    Message
                  </Label>
                  <Textarea
                    id="message"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Explain why you need this food and when you can pick it up"
                    className="col-span-3"
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? 'Sending...' : 'Send Request'}
                </Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default RequestFoodButton;
