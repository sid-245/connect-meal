
import React from 'react';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';

export interface CategoryOption {
  id: string;
  label: string;
}

interface CategoriesFieldProps {
  title: string;
  options: CategoryOption[];
  selected: string[];
  onChange: (id: string) => void;
}

const CategoriesField = ({ title, options, selected, onChange }: CategoriesFieldProps) => {
  return (
    <div className="space-y-3">
      <Label>{title}</Label>
      <div className="grid grid-cols-2 gap-2">
        {options.map((option) => (
          <div key={option.id} className="flex items-center space-x-2">
            <Checkbox 
              id={`option-${option.id}`} 
              checked={selected.includes(option.id)}
              onCheckedChange={() => onChange(option.id)}
            />
            <Label htmlFor={`option-${option.id}`}>{option.label}</Label>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CategoriesField;
