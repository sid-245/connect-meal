import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import ImageUploadField from './ImageUploadField';
import CategoriesField, { CategoryOption } from './CategoriesField';
import LocationPicker from './LocationPicker';

interface DonationFormProps {
  title: string;
  setTitle: (value: string) => void;
  description: string;
  setDescription: (value: string) => void;
  quantity: string;
  setQuantity: (value: string) => void;
  address: string;
  setAddress: (value: string) => void;
  city: string;
  setCity: (value: string) => void;
  expiryHours: string;
  setExpiryHours: (value: string) => void;
  temperature: 'hot' | 'cold' | 'frozen' | 'room-temperature';
  setTemperature: (value: 'hot' | 'cold' | 'frozen' | 'room-temperature') => void;
  categories: string[];
  handleCategoryChange: (id: string) => void;
  dietaryInfo: string[];
  handleDietaryChange: (id: string) => void;
  imagePreview: string | null;
  handleImageChange: (file: File | null, preview: string | null) => void;
  coordinates: {lat: number, lng: number} | null;
  handleLocationChange: (lat: number, lng: number) => void;
  isLoading: boolean;
  onSubmit: (e: React.FormEvent) => void;
}

const DonationForm = ({
  title, setTitle,
  description, setDescription,
  quantity, setQuantity,
  address, setAddress,
  city, setCity,
  expiryHours, setExpiryHours,
  temperature, setTemperature,
  categories, handleCategoryChange,
  dietaryInfo, handleDietaryChange,
  imagePreview, handleImageChange,
  coordinates, handleLocationChange,
  isLoading, onSubmit
}: DonationFormProps) => {
  
  const categoryOptions: CategoryOption[] = [
    { id: 'prepared-food', label: 'Prepared Food' },
    { id: 'produce', label: 'Produce' },
    { id: 'bakery', label: 'Bakery' },
    { id: 'canned-goods', label: 'Canned Goods' },
    { id: 'dairy', label: 'Dairy' },
  ];

  const dietaryOptions: CategoryOption[] = [
    { id: 'vegan', label: 'Vegan' },
    { id: 'vegetarian', label: 'Vegetarian' },
    { id: 'gluten-free', label: 'Gluten Free' },
    { id: 'dairy-free', label: 'Dairy Free' },
    { id: 'nut-free', label: 'Nut Free' },
  ];

  return (
    <form onSubmit={onSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="title">Food Title</Label>
        <Input 
          id="title" 
          placeholder="E.g., Fresh Sandwiches, Leftover Pizza, Surplus Fruit"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea 
          id="description" 
          placeholder="Describe the food, its condition, and any other relevant information"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="quantity">Quantity</Label>
          <Input 
            id="quantity" 
            placeholder="E.g., 10 sandwiches, 5 lbs of apples"
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="expiry">Expiry Time</Label>
          <Select value={expiryHours} onValueChange={setExpiryHours}>
            <SelectTrigger>
              <SelectValue placeholder="Select expiry time" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="6">Within 6 hours</SelectItem>
              <SelectItem value="12">Within 12 hours</SelectItem>
              <SelectItem value="24">Within 24 hours</SelectItem>
              <SelectItem value="48">Within 2 days</SelectItem>
              <SelectItem value="72">Within 3 days</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <LocationPicker 
        coordinates={coordinates}
        onLocationChange={handleLocationChange}
        address={address}
        onAddressChange={setAddress}
      />
      
      <div className="space-y-2">
        <Label htmlFor="city">City</Label>
        <Input 
          id="city" 
          placeholder="Enter city (e.g., San Francisco)"
          value={city}
          onChange={(e) => setCity(e.target.value)}
          required
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="temperature">Food Temperature</Label>
        <Select value={temperature} onValueChange={(value) => setTemperature(value as any)}>
          <SelectTrigger>
            <SelectValue placeholder="Select temperature" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="hot">Hot</SelectItem>
            <SelectItem value="cold">Cold (Refrigerated)</SelectItem>
            <SelectItem value="frozen">Frozen</SelectItem>
            <SelectItem value="room-temperature">Room Temperature</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <ImageUploadField 
        imagePreview={imagePreview} 
        onImageChange={handleImageChange} 
      />
      
      <CategoriesField
        title="Food Categories"
        options={categoryOptions}
        selected={categories}
        onChange={handleCategoryChange}
      />
      
      <CategoriesField
        title="Dietary Information"
        options={dietaryOptions}
        selected={dietaryInfo}
        onChange={handleDietaryChange}
      />
      
      <Button 
        type="submit" 
        className="w-full bg-connect-green-500 hover:bg-connect-green-600"
        disabled={isLoading}
      >
        {isLoading ? 'Listing Food...' : 'List Food for Donation'}
      </Button>
    </form>
  );
};

export default DonationForm;
