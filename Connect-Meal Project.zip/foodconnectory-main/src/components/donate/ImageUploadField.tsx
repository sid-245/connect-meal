
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ImagePlus } from 'lucide-react';

interface ImageUploadFieldProps {
  imagePreview: string | null;
  onImageChange: (file: File | null, preview: string | null) => void;
}

const ImageUploadField = ({ imagePreview, onImageChange }: ImageUploadFieldProps) => {
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onImageChange(file, reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    onImageChange(null, null);
  };

  return (
    <div className="space-y-3">
      <Label htmlFor="food-image">Food Image</Label>
      {imagePreview ? (
        <div className="relative rounded-md overflow-hidden aspect-video w-full">
          <img 
            src={imagePreview} 
            alt="Food preview" 
            className="w-full h-full object-cover"
          />
          <Button 
            type="button"
            variant="destructive" 
            size="sm"
            className="absolute top-2 right-2"
            onClick={handleRemoveImage}
          >
            Remove
          </Button>
        </div>
      ) : (
        <div className="border-2 border-dashed border-gray-300 rounded-md p-6 text-center">
          <div className="flex flex-col items-center">
            <ImagePlus className="h-12 w-12 text-gray-400 mb-3" />
            <p className="text-sm text-gray-500 mb-2">Click to upload a photo of your food donation</p>
            <p className="text-xs text-gray-400">PNG, JPG, GIF up to 10MB</p>
            <Input
              id="food-image"
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleImageChange}
            />
            <Button 
              type="button"
              variant="outline" 
              className="mt-4"
              onClick={() => document.getElementById('food-image')?.click()}
            >
              Select Image
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ImageUploadField;
