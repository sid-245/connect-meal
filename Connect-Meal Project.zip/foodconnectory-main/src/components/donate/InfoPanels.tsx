
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const InfoPanels = () => {
  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Food Safety Guidelines</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-connect-light-700">
            Please follow these guidelines to ensure food safety:
          </p>
          
          <ul className="text-sm text-connect-light-700 space-y-2 list-disc pl-5">
            <li>Only donate food that is still safe to eat</li>
            <li>Keep hot food hot (above 140°F) and cold food cold (below 40°F)</li>
            <li>Package food in clean, food-safe containers</li>
            <li>Clearly label food with contents and preparation date</li>
            <li>Be honest about expiration dates and food quality</li>
          </ul>
          
          <p className="text-sm text-connect-light-700 mt-4">
            Remember, your donated food will be consumed by others, so please maintain the highest standards of food safety.
          </p>
        </CardContent>
      </Card>
      
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Donation Tips</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-connect-light-700">
            Here are some tips to make your food donation more successful:
          </p>
          
          <ul className="text-sm text-connect-light-700 space-y-2 list-disc pl-5">
            <li>Take a clear, appetizing photo of the food</li>
            <li>Be specific about quantity and portions</li>
            <li>Provide detailed pickup instructions</li>
            <li>Be responsive to messages from potential recipients</li>
            <li>Update the listing if anything changes</li>
          </ul>
        </CardContent>
      </Card>
    </>
  );
};

export default InfoPanels;
