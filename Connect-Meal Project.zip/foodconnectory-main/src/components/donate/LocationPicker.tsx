
import React, { useEffect, useRef, useState } from 'react';
import { MapPin, Search, Loader2 } from 'lucide-react';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

// Fix Leaflet marker icon issue
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34]
});

L.Marker.prototype.options.icon = DefaultIcon;

// Component to update map view when coordinates change
function UpdateMapView({ center }: { center: [number, number] }) {
  const map = useMapEvents({
    click: () => {
      // We don't handle map clicks anymore
    }
  });
  
  useEffect(() => {
    map.setView(center, 15); // Zoom level increased for better visibility
  }, [center]);
  
  return null;
}

interface LocationPickerProps {
  coordinates: {lat: number, lng: number} | null;
  onLocationChange: (lat: number, lng: number) => void;
  address: string;
  onAddressChange: (address: string) => void;
}

const LocationPicker = ({ 
  coordinates, 
  onLocationChange, 
  address, 
  onAddressChange 
}: LocationPickerProps) => {
  const [mapReady, setMapReady] = useState(false);
  const [isGeocoding, setIsGeocoding] = useState(false);
  const { toast } = useToast();

  // Set default coordinates if none provided
  const position = coordinates ? 
    [coordinates.lat, coordinates.lng] as [number, number] : 
    [40.7128, -74.0060] as [number, number];

  useEffect(() => {
    setMapReady(true);
  }, []);

  const handleGeocodeAddress = async () => {
    if (!address.trim()) {
      toast({
        title: "Address Required",
        description: "Please enter an address to search",
        variant: "destructive"
      });
      return;
    }

    setIsGeocoding(true);
    try {
      // Using OpenStreetMap Nominatim API for geocoding (free and no API key required)
      const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(address)}`);
      const data = await response.json();
      
      if (data && data.length > 0) {
        const { lat, lon } = data[0];
        const latitude = parseFloat(lat);
        const longitude = parseFloat(lon);
        
        onLocationChange(latitude, longitude);
        toast({
          title: "Location Updated",
          description: "Map has been updated with the provided address"
        });
      } else {
        toast({
          title: "Address Not Found",
          description: "Could not find coordinates for the provided address. Please try being more specific.",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Geocoding Error",
        description: "An error occurred while finding the location. Please try again.",
        variant: "destructive"
      });
      console.error("Geocoding error:", error);
    } finally {
      setIsGeocoding(false);
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="text-sm font-medium">Pickup Location</label>
        <span className="text-xs text-gray-500">Enter your address to set your location</span>
      </div>
      
      <div className="flex gap-2">
        <Input 
          id="address" 
          placeholder="Enter full address where food can be picked up" 
          value={address}
          onChange={(e) => onAddressChange(e.target.value)}
          className="flex-1"
        />
        <Button 
          onClick={handleGeocodeAddress} 
          disabled={isGeocoding || !address.trim()}
          type="button"
        >
          {isGeocoding ? (
            <Loader2 className="h-4 w-4 animate-spin mr-1" />
          ) : (
            <Search className="h-4 w-4 mr-1" />
          )}
          Find
        </Button>
      </div>

      <div className="h-64 w-full rounded-lg overflow-hidden border border-gray-200" style={{ zIndex: 0 }}>
        {mapReady ? (
          <MapContainer 
            center={position} 
            zoom={15} 
            style={{ height: '100%', width: '100%' }}
            attributionControl={true}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            
            <UpdateMapView center={position} />
            
            {/* Static marker (not draggable) */}
            <Marker position={position} />
          </MapContainer>
        ) : (
          <div className="h-full w-full flex items-center justify-center bg-gray-100">
            <MapPin className="h-8 w-8 text-gray-400" />
            <span className="ml-2 text-gray-500">Loading map...</span>
          </div>
        )}
      </div>
      <div className="text-xs text-gray-500 mt-1 flex justify-between">
        <span>Current coordinates: {position[0].toFixed(6)}, {position[1].toFixed(6)}</span>
        <button 
          type="button"
          onClick={() => navigator.clipboard.writeText(`${position[0].toFixed(6)}, ${position[1].toFixed(6)}`)}
          className="text-blue-600 hover:underline"
        >
          Copy
        </button>
      </div>
    </div>
  );
};

export default LocationPicker;
