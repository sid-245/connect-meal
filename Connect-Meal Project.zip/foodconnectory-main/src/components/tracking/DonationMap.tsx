
import React, { useEffect, useState } from 'react';
import { FoodItem } from '@/types';
import { Card } from '@/components/ui/card';
import { MapPin, Navigation } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix Leaflet marker icon issue
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34]
});

L.Marker.prototype.options.icon = DefaultIcon;

// Component to update map view when coordinates change
function UpdateMapView({ center }: { center: [number, number] }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, map.getZoom());
  }, [center, map]);
  return null;
}

interface DonationMapProps {
  donation: FoodItem;
  isInteractive?: boolean;
}

const DonationMap = ({ donation, isInteractive = false }: DonationMapProps) => {
  const [mapReady, setMapReady] = useState(false);

  // Determine center coordinates for the map
  const hasInitialCoordinates = donation.location.coordinates?.lat && donation.location.coordinates?.lng;
  const hasCurrentLocation = donation.currentLocation?.lat && donation.currentLocation?.lng;
  
  const centerCoordinates = hasCurrentLocation 
    ? [donation.currentLocation!.lat, donation.currentLocation!.lng] as [number, number]
    : hasInitialCoordinates 
      ? [donation.location.coordinates!.lat, donation.location.coordinates!.lng] as [number, number]
      : [0, 0] as [number, number];

  // Prepare polyline if we have tracking history
  const pathCoordinates = donation.trackingHistory 
    ? donation.trackingHistory.map(point => [point.lat, point.lng] as [number, number]) 
    : [];

  // If no location data is available
  if (!hasInitialCoordinates && !hasCurrentLocation) {
    return (
      <div className="h-full flex items-center justify-center flex-col gap-4 bg-gray-50 rounded-lg border border-gray-200">
        <MapPin size={48} className="text-gray-400" />
        <div className="text-center">
          <p className="text-red-500">No location data available for this donation</p>
        </div>
      </div>
    );
  }

  useEffect(() => {
    setMapReady(true);
  }, []);

  return (
    <div className="h-full w-full rounded-lg overflow-hidden relative" style={{ zIndex: 0 }}>
      {mapReady && (
        <MapContainer 
          center={centerCoordinates} 
          zoom={13} 
          style={{ height: '100%', width: '100%' }}
          attributionControl={true}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          
          {/* Update map view when coordinates change */}
          <UpdateMapView center={centerCoordinates} />
          
          {/* Marker for pickup location */}
          {hasInitialCoordinates && (
            <Marker 
              position={[donation.location.coordinates!.lat, donation.location.coordinates!.lng]}
              icon={new L.Icon({
                iconUrl: icon,
                shadowUrl: iconShadow,
                iconSize: [25, 41],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34],
                className: 'pickup-marker'
              })}
            >
              <Popup>
                <div>
                  <h3 className="font-semibold">Pickup Location</h3>
                  <p>{donation.location.address}</p>
                </div>
              </Popup>
            </Marker>
          )}
          
          {/* Marker for current location */}
          {hasCurrentLocation && (
            <Marker 
              position={[donation.currentLocation!.lat, donation.currentLocation!.lng]}
              icon={new L.Icon({
                iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
                shadowUrl: iconShadow,
                iconSize: [25, 41],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34],
                className: 'current-marker'
              })}
            >
              <Popup>
                <div>
                  <h3 className="font-semibold">Current Location</h3>
                  <p>Updated: {new Date(donation.currentLocation!.timestamp).toLocaleString()}</p>
                </div>
              </Popup>
            </Marker>
          )}
          
          {/* Path line if we have tracking history */}
          {pathCoordinates.length > 1 && (
            <Polyline 
              positions={pathCoordinates}
              color="#3887be"
              weight={5}
              opacity={0.75}
            />
          )}
        </MapContainer>
      )}
    </div>
  );
};

export default DonationMap;
