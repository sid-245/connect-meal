
import React from 'react';
import { FoodItem } from '@/types';
import { Button } from '@/components/ui/button';
import { Navigation, Package, Check, Clock } from 'lucide-react';

interface DonationTrackingInfoProps {
  donation: FoodItem;
  onStatusUpdate?: (status: 'pending' | 'in_transit' | 'delivered') => void;
}

const DonationTrackingInfo = ({ donation, onStatusUpdate }: DonationTrackingInfoProps) => {
  const currentStatus = donation.pickupStatus || 'pending';
  
  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString();
  };
  
  return (
    <div className="space-y-4">
      <div>
        <h3 className="font-semibold text-lg">{donation.title}</h3>
        <p className="text-sm text-gray-600">Donated by: {donation.donorName}</p>
      </div>
      
      <div className="border-t pt-4">
        <h4 className="font-medium mb-2">Pickup Address</h4>
        <p className="text-sm">{donation.location.address}</p>
      </div>
      
      <div className="border-t pt-4">
        <h4 className="font-medium mb-2">Tracking Timeline</h4>
        
        <div className="space-y-4 mt-4">
          <div className="flex items-start gap-3">
            <div className={`p-2 rounded-full ${currentStatus === 'pending' ? 'bg-yellow-100 text-yellow-600' : 'bg-green-100 text-green-600'}`}>
              <Package size={16} />
            </div>
            <div>
              <p className="font-medium">Pending Pickup</p>
              <p className="text-xs text-gray-500">
                {donation.createdAt ? formatTimestamp(donation.createdAt) : 'N/A'}
              </p>
            </div>
          </div>
          
          <div className="flex items-start gap-3">
            <div className={`p-2 rounded-full ${currentStatus === 'in_transit' ? 'bg-blue-100 text-blue-600' : currentStatus === 'delivered' ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'}`}>
              <Navigation size={16} />
            </div>
            <div>
              <p className={`font-medium ${currentStatus === 'pending' ? 'text-gray-400' : ''}`}>In Transit</p>
              {currentStatus !== 'pending' && donation.currentLocation ? (
                <p className="text-xs text-gray-500">
                  {formatTimestamp(donation.currentLocation.timestamp)}
                </p>
              ) : (
                <p className="text-xs text-gray-500">Not started yet</p>
              )}
            </div>
          </div>
          
          <div className="flex items-start gap-3">
            <div className={`p-2 rounded-full ${currentStatus === 'delivered' ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'}`}>
              <Check size={16} />
            </div>
            <div>
              <p className={`font-medium ${currentStatus !== 'delivered' ? 'text-gray-400' : ''}`}>Delivered</p>
              {currentStatus === 'delivered' && donation.trackingHistory && donation.trackingHistory.length > 0 ? (
                <p className="text-xs text-gray-500">
                  {formatTimestamp(donation.trackingHistory[donation.trackingHistory.length - 1].timestamp)}
                </p>
              ) : (
                <p className="text-xs text-gray-500">Not delivered yet</p>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {onStatusUpdate && (
        <div className="border-t pt-4">
          <h4 className="font-medium mb-2">Update Status</h4>
          <div className="flex flex-col gap-2">
            {currentStatus === 'pending' && (
              <Button 
                variant="outline"
                className="bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100"
                onClick={() => onStatusUpdate('in_transit')}
              >
                <Navigation size={16} className="mr-2" />
                Start Transit
              </Button>
            )}
            {currentStatus === 'in_transit' && (
              <Button 
                variant="outline"
                className="bg-green-50 text-green-700 border-green-200 hover:bg-green-100"
                onClick={() => onStatusUpdate('delivered')}
              >
                <Check size={16} className="mr-2" />
                Mark as Delivered
              </Button>
            )}
            {currentStatus === 'delivered' && (
              <p className="text-sm text-gray-500 italic">Donation has been delivered</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default DonationTrackingInfo;
