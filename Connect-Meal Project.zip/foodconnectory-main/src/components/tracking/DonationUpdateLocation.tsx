
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { MapPin, Navigation, Locate } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface DonationUpdateLocationProps {
  onLocationUpdate: (lat: number, lng: number) => void;
}

const DonationUpdateLocation = ({ onLocationUpdate }: DonationUpdateLocationProps) => {
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  const [isAutoTracking, setIsAutoTracking] = useState(false);
  const [trackingInterval, setTrackingIntervalId] = useState<number | null>(null);
  const { toast } = useToast();

  // Cleanup tracking interval on unmount
  useEffect(() => {
    return () => {
      if (trackingInterval) {
        window.clearInterval(trackingInterval);
      }
    };
  }, [trackingInterval]);

  const handleManualUpdate = () => {
    const lat = parseFloat(latitude);
    const lng = parseFloat(longitude);
    
    if (isNaN(lat) || isNaN(lng)) {
      toast({
        title: 'Invalid coordinates',
        description: 'Please enter valid numbers for latitude and longitude',
        variant: 'destructive',
      });
      return;
    }
    
    if (lat < -90 || lat > 90) {
      toast({
        title: 'Invalid latitude',
        description: 'Latitude must be between -90 and 90 degrees',
        variant: 'destructive',
      });
      return;
    }
    
    if (lng < -180 || lng > 180) {
      toast({
        title: 'Invalid longitude',
        description: 'Longitude must be between -180 and 180 degrees',
        variant: 'destructive',
      });
      return;
    }
    
    onLocationUpdate(lat, lng);
    
    toast({
      title: 'Location updated',
      description: 'The donation location has been updated successfully',
    });
  };
  
  const getCurrentLocation = () => {
    setIsGettingLocation(true);
    
    if (!navigator.geolocation) {
      toast({
        title: 'Geolocation not supported',
        description: 'Your browser does not support geolocation',
        variant: 'destructive',
      });
      setIsGettingLocation(false);
      return;
    }
    
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setLatitude(latitude.toString());
        setLongitude(longitude.toString());
        onLocationUpdate(latitude, longitude);
        
        toast({
          title: 'Location updated',
          description: 'Your current location has been updated successfully',
        });
        setIsGettingLocation(false);
      },
      (error) => {
        let errorMessage = 'Unknown error occurred';
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = 'Permission to access location was denied';
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = 'Location information is unavailable';
            break;
          case error.TIMEOUT:
            errorMessage = 'The request to get location timed out';
            break;
        }
        
        toast({
          title: 'Location error',
          description: errorMessage,
          variant: 'destructive',
        });
        setIsGettingLocation(false);
      },
      { 
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0
      }
    );
  };

  const toggleAutoTracking = () => {
    if (isAutoTracking) {
      // Stop tracking
      if (trackingInterval) {
        window.clearInterval(trackingInterval);
        setTrackingIntervalId(null);
      }
      setIsAutoTracking(false);
      toast({
        title: 'Auto-tracking stopped',
        description: 'Location updates have been paused',
      });
    } else {
      // Start auto-tracking
      if (!navigator.geolocation) {
        toast({
          title: 'Geolocation not supported',
          description: 'Your browser does not support geolocation',
          variant: 'destructive',
        });
        return;
      }

      // First get current position
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setLatitude(latitude.toString());
          setLongitude(longitude.toString());
          onLocationUpdate(latitude, longitude);
          
          // Then set up interval for continued tracking
          const intervalId = window.setInterval(() => {
            navigator.geolocation.getCurrentPosition(
              (position) => {
                const { latitude, longitude } = position.coords;
                setLatitude(latitude.toString());
                setLongitude(longitude.toString());
                onLocationUpdate(latitude, longitude);
                console.log('Auto-updated location:', latitude, longitude);
              },
              (error) => {
                console.error('Error getting location during auto-tracking:', error);
              },
              { 
                enableHighAccuracy: true,
                timeout: 5000,
                maximumAge: 0
              }
            );
          }, 30000); // Update every 30 seconds
          
          setTrackingIntervalId(intervalId);
          setIsAutoTracking(true);
          
          toast({
            title: 'Auto-tracking started',
            description: 'Your location will update automatically every 30 seconds',
          });
        },
        (error) => {
          let errorMessage = 'Unknown error occurred';
          switch (error.code) {
            case error.PERMISSION_DENIED:
              errorMessage = 'Permission to access location was denied';
              break;
            case error.POSITION_UNAVAILABLE:
              errorMessage = 'Location information is unavailable';
              break;
            case error.TIMEOUT:
              errorMessage = 'The request to get location timed out';
              break;
          }
          
          toast({
            title: 'Location error',
            description: errorMessage,
            variant: 'destructive',
          });
        },
        { 
          enableHighAccuracy: true,
          timeout: 5000,
          maximumAge: 0
        }
      );
    }
  };
  
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <div className="space-y-1">
          <label htmlFor="latitude" className="text-sm font-medium">Latitude</label>
          <Input
            id="latitude"
            type="text"
            placeholder="e.g., 40.7128"
            value={latitude}
            onChange={(e) => setLatitude(e.target.value)}
            disabled={isAutoTracking}
          />
        </div>
        <div className="space-y-1">
          <label htmlFor="longitude" className="text-sm font-medium">Longitude</label>
          <Input
            id="longitude"
            type="text"
            placeholder="e.g., -74.0060"
            value={longitude}
            onChange={(e) => setLongitude(e.target.value)}
            disabled={isAutoTracking}
          />
        </div>
      </div>
      
      <div className="flex flex-col gap-2">
        <Button 
          variant="outline" 
          onClick={handleManualUpdate}
          disabled={!latitude || !longitude || isAutoTracking}
        >
          <MapPin size={16} className="mr-2" />
          Update Manually
        </Button>
        
        <Button
          onClick={getCurrentLocation}
          disabled={isGettingLocation || isAutoTracking}
          className="bg-connect-green-500 hover:bg-connect-green-600"
        >
          {isGettingLocation ? (
            <>Getting location...</>
          ) : (
            <>
              <Locate size={16} className="mr-2" />
              Use Current Location
            </>
          )}
        </Button>

        <Button
          onClick={toggleAutoTracking}
          variant={isAutoTracking ? "destructive" : "default"}
          className={isAutoTracking ? "" : "bg-blue-500 hover:bg-blue-600"}
        >
          <Navigation size={16} className="mr-2" />
          {isAutoTracking ? "Stop Auto-Tracking" : "Start Auto-Tracking"}
        </Button>
      </div>
    </div>
  );
};

export default DonationUpdateLocation;
