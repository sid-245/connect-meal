import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, FoodItem, FoodRequest, Notification } from '../types';
import { mockUsers, mockFoodItems, mockFoodRequests, mockNotifications } from '../data/mockData';

interface AppContextType {
  currentUser: User | null;
  setCurrentUser: React.Dispatch<React.SetStateAction<User | null>>;
  foodItems: FoodItem[];
  foodRequests: FoodRequest[];
  notifications: Notification[];
  addFoodItem: (item: Omit<FoodItem, 'id' | 'createdAt' | 'donorName'>) => void;
  updateFoodItem: (id: string, updates: Partial<FoodItem>) => void;
  requestFood: (request: Omit<FoodRequest, 'id' | 'createdAt' | 'requesterName'>) => void;
  updateFoodRequest: (id: string, updates: Partial<FoodRequest>) => void;
  markNotificationAsRead: (id: string) => void;
  login: (email: string, password: string) => Promise<User>;
  register: (user: Partial<User>, password: string) => Promise<User>;
  logout: () => void;
  isLoading: boolean;
  users: User[];
  checkPhoneVerified: () => boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [foodItems, setFoodItems] = useState<FoodItem[]>([]);
  const [foodRequests, setFoodRequests] = useState<FoodRequest[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [users, setUsers] = useState<User[]>([]);

  useEffect(() => {
    const storedUsers = localStorage.getItem('connectmeal-users');
    const parsedUsers = storedUsers ? JSON.parse(storedUsers) : mockUsers;
    
    const storedCurrentUser = localStorage.getItem('connectmeal-current-user');
    if (storedCurrentUser) {
      setCurrentUser(JSON.parse(storedCurrentUser));
    }
    
    setUsers(parsedUsers);
    
    setTimeout(() => {
      setFoodItems(mockFoodItems);
      setFoodRequests(mockFoodRequests);
      setNotifications(mockNotifications);
      setIsLoading(false);
    }, 1000);
  }, []);
  
  useEffect(() => {
    if (users.length > 0) {
      localStorage.setItem('connectmeal-users', JSON.stringify(users));
    }
  }, [users]);
  
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('connectmeal-current-user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('connectmeal-current-user');
    }
  }, [currentUser]);

  const checkPhoneVerified = () => {
    if (!currentUser) return false;
    return currentUser.phoneVerified === true;
  };

  const addFoodItem = (item: Omit<FoodItem, 'id' | 'createdAt' | 'donorName'>) => {
    if (!currentUser) {
      throw new Error('User must be logged in to add a food item');
    }
    
    if (!checkPhoneVerified()) {
      throw new Error('Phone verification required to donate food');
    }
    
    if (!item.location.coordinates) {
      console.error("No coordinates provided for food item");
      throw new Error('Location coordinates are required for donation');
    }
    
    if (!item.location.city) {
      console.error("No city provided for food item");
      throw new Error('City is required for donation');
    }
    
    console.log("Adding food item with location:", item.location);
    
    const newItem: FoodItem = {
      ...item,
      id: `food${Date.now()}`,
      createdAt: new Date().toISOString(),
      donorId: currentUser.id,
      donorName: currentUser.name
    };
    
    setFoodItems(prev => [...prev, newItem]);
    return newItem;
  };

  const updateFoodItem = (id: string, updates: Partial<FoodItem>) => {
    setFoodItems(prev => 
      prev.map(item => 
        item.id === id ? { ...item, ...updates } : item
      )
    );
  };

  const requestFood = (request: Omit<FoodRequest, 'id' | 'createdAt' | 'requesterName'>) => {
    if (!currentUser) {
      throw new Error('User must be logged in to request food');
    }
    
    if (!checkPhoneVerified()) {
      throw new Error('Phone verification required to request food');
    }
    
    const newRequest: FoodRequest = {
      ...request,
      id: `request${Date.now()}`,
      createdAt: new Date().toISOString(),
      requesterId: currentUser.id,
      requesterName: currentUser.name
    };
    
    setFoodRequests(prev => [...prev, newRequest]);
    
    const foodItem = foodItems.find(item => item.id === request.foodItemId);
    if (foodItem) {
      const newNotification: Notification = {
        id: `notif${Date.now()}`,
        userId: foodItem.donorId,
        message: `New request for your "${foodItem.title}" from ${currentUser.name}`,
        read: false,
        createdAt: new Date().toISOString(),
        type: 'request',
        relatedItemId: foodItem.id
      };
      
      setNotifications(prev => [...prev, newNotification]);
    }
    
    return newRequest;
  };

  const updateFoodRequest = (id: string, updates: Partial<FoodRequest>) => {
    setFoodRequests(prev => 
      prev.map(request => 
        request.id === id ? { ...request, ...updates } : request
      )
    );
    
    if (updates.status) {
      const request = foodRequests.find(req => req.id === id);
      const foodItem = request ? foodItems.find(item => item.id === request.foodItemId) : null;
      
      if (request && foodItem) {
        const statusText = updates.status === 'approved' ? 'approved' : 
                         updates.status === 'rejected' ? 'rejected' : 
                         updates.status === 'completed' ? 'marked as completed' : 'updated';
        
        const newNotification: Notification = {
          id: `notif${Date.now()}`,
          userId: request.requesterId,
          message: `Your request for "${foodItem.title}" has been ${statusText}`,
          read: false,
          createdAt: new Date().toISOString(),
          type: 'request',
          relatedItemId: foodItem.id
        };
        
        setNotifications(prev => [...prev, newNotification]);
      }
    }
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.id === id ? { ...notification, read: true } : notification
      )
    );
  };

  const login = async (email: string, password: string): Promise<User> => {
    setIsLoading(true);
    
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const user = users.find(u => u.email === email);
        
        if (user && (password === 'password' || password === user.password)) {
          setCurrentUser(user);
          setIsLoading(false);
          resolve(user);
        } else {
          setIsLoading(false);
          reject(new Error('Invalid email or password'));
        }
      }, 1000);
    });
  };

  const register = async (user: Partial<User>, password: string): Promise<User> => {
    setIsLoading(true);
    
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const existingUser = users.find(u => u.email === user.email);
        
        if (existingUser) {
          setIsLoading(false);
          reject(new Error('Email already in use'));
        } else {
          const newUser: User = {
            id: `user${Date.now()}`,
            name: user.name || '',
            email: user.email || '',
            role: user.role || 'receiver',
            phone: user.phone || '',
            phoneVerified: user.phoneVerified || false,
            verified: false,
            createdAt: new Date().toISOString(),
            password: password
          };
          
          setUsers(prevUsers => [...prevUsers, newUser]);
          
          setCurrentUser(newUser);
          setIsLoading(false);
          resolve(newUser);
        }
      }, 1000);
    });
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('connectmeal-current-user');
  };

  const value = {
    currentUser,
    setCurrentUser,
    foodItems,
    foodRequests,
    notifications,
    addFoodItem,
    updateFoodItem,
    requestFood,
    updateFoodRequest,
    markNotificationAsRead,
    login,
    register,
    logout,
    isLoading,
    users,
    checkPhoneVerified
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
