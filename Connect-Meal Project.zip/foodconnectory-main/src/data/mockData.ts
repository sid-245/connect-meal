
import { FoodItem, FoodRequest, User, Notification } from '../types';

export const mockUsers: User[] = [
  {
    id: 'user1',
    name: 'Jane Smith',
    email: 'jane@example.com',
    role: 'donor',
    avatar: 'https://randomuser.me/api/portraits/women/44.jpg',
    phone: '(555) 123-4567',
    address: '123 Maple Ave, Springfield',
    verified: true,
    createdAt: '2023-01-15T10:30:00Z'
  },
  {
    id: 'user2',
    name: 'John Doe',
    email: 'john@example.com',
    role: 'receiver',
    avatar: 'https://randomuser.me/api/portraits/men/32.jpg',
    phone: '(555) 987-6543',
    address: '456 Oak St, Springfield',
    verified: true,
    createdAt: '2023-02-20T14:45:00Z'
  },
  {
    id: 'user3',
    name: 'Food For All',
    email: 'contact@foodforall.org',
    role: 'ngo',
    avatar: 'https://images.unsplash.com/photo-1607113725037-5de1b0a2d0f5?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80',
    phone: '(555) 456-7890',
    address: '789 Charity Blvd, Springfield',
    verified: true,
    createdAt: '2022-11-05T09:15:00Z'
  },
  {
    id: 'user4',
    name: 'Sarah Johnson',
    email: 'sarah@example.com',
    role: 'donor',
    avatar: 'https://randomuser.me/api/portraits/women/28.jpg',
    phone: '(555) 765-4321',
    address: '567 Pine St, Springfield',
    verified: true,
    createdAt: '2023-03-10T11:20:00Z'
  },
  {
    id: 'user5',
    name: 'Mark Wilson',
    email: 'mark@example.com',
    role: 'receiver',
    avatar: 'https://randomuser.me/api/portraits/men/45.jpg',
    phone: '(555) 234-5678',
    address: '890 Cedar Ave, Springfield',
    verified: true,
    createdAt: '2023-02-05T09:30:00Z'
  },
  {
    id: 'user6',
    name: 'Community Helpers',
    email: 'help@communityhelpers.org',
    role: 'ngo',
    avatar: 'https://images.unsplash.com/photo-1544027993-37dbfe43562a?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80',
    phone: '(555) 876-5432',
    address: '123 Volunteer St, Springfield',
    verified: true,
    createdAt: '2022-12-15T14:25:00Z'
  }
];

export const mockFoodItems: FoodItem[] = [
  {
    id: 'food1',
    title: 'Fresh Sandwiches from Café',
    description: 'Assorted sandwiches left over from a corporate lunch event. Individually wrapped and kept refrigerated.',
    quantity: '15 sandwiches',
    expiryDate: new Date(Date.now() + 86400000).toISOString(), // 24 hours from now
    createdAt: new Date(Date.now() - 3600000).toISOString(), // 1 hour ago
    status: 'available',
    location: {
      address: '123 Business Plaza, Downtown',
      coordinates: {
        lat: 40.7128,
        lng: -74.0060
      }
    },
    donorId: 'user1',
    donorName: 'Jane Smith',
    imageUrl: 'https://images.unsplash.com/photo-1567234669003-dce7a7a88821?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    dietaryInfo: ['Contains Gluten', 'Contains Dairy'],
    temperature: 'cold',
    categories: ['Prepared Food', 'Sandwiches'],
    pickupStatus: 'pending'
  },
  {
    id: 'food2',
    title: 'Vegetable Soup - 5 Gallons',
    description: 'Homemade vegetable soup. Very nutritious with carrots, celery, onions, and potatoes. Made today.',
    quantity: '5 gallons',
    expiryDate: new Date(Date.now() + 172800000).toISOString(), // 48 hours from now
    createdAt: new Date(Date.now() - 7200000).toISOString(), // 2 hours ago
    status: 'available',
    location: {
      address: '456 Community Kitchen, Westside',
      coordinates: {
        lat: 40.7328,
        lng: -74.0260
      }
    },
    donorId: 'user3',
    donorName: 'Food For All',
    imageUrl: 'https://images.unsplash.com/photo-1616501268509-9ce94939e644?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    dietaryInfo: ['Vegan', 'Gluten-Free'],
    temperature: 'hot',
    categories: ['Soup', 'Prepared Food'],
    pickupStatus: 'in_transit',
    currentLocation: {
      lat: 40.7350,
      lng: -74.0280,
      timestamp: new Date(Date.now() - 1800000).toISOString() // 30 minutes ago
    },
    trackingHistory: [
      {
        lat: 40.7328,
        lng: -74.0260,
        timestamp: new Date(Date.now() - 3600000).toISOString() // 1 hour ago
      },
      {
        lat: 40.7340,
        lng: -74.0270,
        timestamp: new Date(Date.now() - 2700000).toISOString() // 45 minutes ago
      },
      {
        lat: 40.7350,
        lng: -74.0280,
        timestamp: new Date(Date.now() - 1800000).toISOString() // 30 minutes ago
      }
    ]
  },
  {
    id: 'food3',
    title: 'Assorted Fruit - 10 lbs',
    description: 'Mixed fruits including apples, oranges, and bananas. All fresh and in good condition.',
    quantity: '10 lbs',
    expiryDate: new Date(Date.now() + 259200000).toISOString(), // 72 hours from now
    createdAt: new Date(Date.now() - 14400000).toISOString(), // 4 hours ago
    status: 'available',
    location: {
      address: '789 Grocery Lane, Eastside',
      coordinates: {
        lat: 40.7428,
        lng: -73.9860
      }
    },
    donorId: 'user1',
    donorName: 'Jane Smith',
    imageUrl: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    dietaryInfo: ['Vegan', 'Raw'],
    temperature: 'room-temperature',
    categories: ['Produce', 'Fruits'],
    pickupStatus: 'pending'
  },
  {
    id: 'food4',
    title: 'Fresh Bread - 20 Loaves',
    description: 'Freshly baked bread from our local bakery. Various types including sourdough, whole wheat, and white.',
    quantity: '20 loaves',
    expiryDate: new Date(Date.now() + 172800000).toISOString(), // 48 hours from now
    createdAt: new Date(Date.now() - 10800000).toISOString(), // 3 hours ago
    status: 'available',
    location: {
      address: '234 Bakery St, Downtown',
      coordinates: {
        lat: 40.7228,
        lng: -74.0100
      }
    },
    donorId: 'user4',
    donorName: 'Sarah Johnson',
    imageUrl: 'https://images.unsplash.com/photo-1549931319-a545dcf3bc7b?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    dietaryInfo: ['Contains Gluten'],
    temperature: 'room-temperature',
    categories: ['Bakery', 'Bread'],
    pickupStatus: 'delivered',
    currentLocation: {
      lat: 40.7240,
      lng: -74.0120,
      timestamp: new Date(Date.now() - 900000).toISOString() // 15 minutes ago
    },
    trackingHistory: [
      {
        lat: 40.7228,
        lng: -74.0100,
        timestamp: new Date(Date.now() - 5400000).toISOString() // 90 minutes ago
      },
      {
        lat: 40.7235,
        lng: -74.0110,
        timestamp: new Date(Date.now() - 3600000).toISOString() // 60 minutes ago
      },
      {
        lat: 40.7240,
        lng: -74.0120,
        timestamp: new Date(Date.now() - 1800000).toISOString() // 30 minutes ago
      }
    ]
  }
];

export const mockFoodRequests: FoodRequest[] = [
  {
    id: 'request1',
    foodItemId: 'food1',
    requesterId: 'user2',
    requesterName: 'John Doe',
    status: 'pending',
    message: 'I would like to collect these for our community dinner tonight.',
    quantity: '10 sandwiches',
    createdAt: new Date(Date.now() - 1800000).toISOString() // 30 minutes ago
  },
  {
    id: 'request2',
    foodItemId: 'food2',
    requesterId: 'user2',
    requesterName: 'John Doe',
    status: 'approved',
    message: 'We can distribute this at our shelter.',
    quantity: '3 gallons',
    createdAt: new Date(Date.now() - 5400000).toISOString() // 90 minutes ago
  },
  {
    id: 'request3',
    foodItemId: 'food3',
    requesterId: 'user5',
    requesterName: 'Mark Wilson',
    status: 'pending',
    message: 'This would be perfect for our food pantry distribution.',
    quantity: '8 lbs',
    createdAt: new Date(Date.now() - 3600000).toISOString() // 1 hour ago
  },
  {
    id: 'request4',
    foodItemId: 'food4',
    requesterId: 'user2',
    requesterName: 'John Doe',
    status: 'completed',
    message: 'We need this for our weekend food program.',
    quantity: '15 loaves',
    createdAt: new Date(Date.now() - 7200000).toISOString() // 2 hours ago
  }
];

export const mockNotifications: Notification[] = [
  {
    id: 'notif1',
    userId: 'user1',
    message: 'Your food donation "Fresh Sandwiches from Café" has a new request!',
    read: false,
    createdAt: new Date(Date.now() - 1800000).toISOString(), // 30 minutes ago
    type: 'request',
    relatedItemId: 'food1'
  },
  {
    id: 'notif2',
    userId: 'user2',
    message: 'Your request for "Vegetable Soup" has been approved!',
    read: true,
    createdAt: new Date(Date.now() - 3600000).toISOString(), // 1 hour ago
    type: 'request',
    relatedItemId: 'food2'
  },
  {
    id: 'notif3',
    userId: 'user3',
    message: 'Your account verification is complete!',
    read: false,
    createdAt: new Date(Date.now() - 86400000).toISOString(), // 24 hours ago
    type: 'verification'
  },
  {
    id: 'notif4',
    userId: 'user1',
    message: 'Your food donation "Assorted Fruit - 10 lbs" has a new request!',
    read: false,
    createdAt: new Date(Date.now() - 2700000).toISOString(), // 45 minutes ago
    type: 'request',
    relatedItemId: 'food3'
  },
  {
    id: 'notif5',
    userId: 'user4',
    message: 'Your donation "Fresh Bread - 20 Loaves" has been delivered!',
    read: false,
    createdAt: new Date(Date.now() - 900000).toISOString(), // 15 minutes ago
    type: 'donation',
    relatedItemId: 'food4'
  }
];
