
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import FoodCard from '@/components/FoodCard';
import { Button } from '@/components/ui/button';
import { FoodItem, FoodRequest } from '@/types';
import { formatDistanceToNow } from 'date-fns';
import { Check, Eye, MessageSquare } from 'lucide-react';
import FoodDetailsModal from '@/components/FoodDetailsModal';
import { useToast } from '@/hooks/use-toast';

const Dashboard = () => {
  const { currentUser, foodItems, foodRequests, isLoading, updateFoodRequest } = useApp();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [selectedFood, setSelectedFood] = useState<FoodItem | null>(null);
  const [detailsModalOpen, setDetailsModalOpen] = useState(false);
  
  // Redirect to login if not authenticated
  useEffect(() => {
    if (!currentUser && !isLoading) {
      navigate('/login');
    }
  }, [currentUser, isLoading, navigate]);
  
  if (isLoading) {
    return (
      <div className="connect-container py-12">
        <p className="text-center">Loading...</p>
      </div>
    );
  }
  
  if (!currentUser) {
    // This will be handled by the useEffect above
    return null;
  }
  
  // Filter data based on user role
  const userFoodItems = foodItems.filter(item => item.donorId === currentUser.id);
  const userFoodRequests = foodRequests.filter(request => request.requesterId === currentUser.id);
  const incomingRequests = foodRequests.filter(
    request => foodItems.some(item => item.id === request.foodItemId && item.donorId === currentUser.id)
  );
  
  const getRequestedFoodItem = (requestId: string): FoodItem | undefined => {
    const request = foodRequests.find(r => r.id === requestId);
    if (!request) return undefined;
    return foodItems.find(item => item.id === request.foodItemId);
  };

  const handleApproveRequest = (requestId: string) => {
    try {
      const updatedRequest = {
        status: 'approved' as const,
        approvedAt: new Date().toISOString()
      };
      
      updateFoodRequest(requestId, updatedRequest);
      
      toast({
        title: "Request approved",
        description: "The food request has been approved successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to approve the request. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleViewDetails = (foodItem: FoodItem) => {
    setSelectedFood(foodItem);
    setDetailsModalOpen(true);
  };
  
  const renderDonorDashboard = () => (
    <>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-2xl">{userFoodItems.length}</CardTitle>
            <CardDescription>Total Donations</CardDescription>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-2xl">
              {userFoodItems.filter(item => item.status === 'available').length}
            </CardTitle>
            <CardDescription>Active Listings</CardDescription>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-2xl">{incomingRequests.length}</CardTitle>
            <CardDescription>Incoming Requests</CardDescription>
          </CardHeader>
        </Card>
      </div>
      
      <Tabs defaultValue="donations">
        <TabsList className="mb-6">
          <TabsTrigger value="donations">My Donations</TabsTrigger>
          <TabsTrigger value="requests">Incoming Requests</TabsTrigger>
        </TabsList>
        
        <TabsContent value="donations">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">My Donations</h2>
            <Button 
              onClick={() => navigate('/donate')}
              className="bg-connect-green-500 hover:bg-connect-green-600"
            >
              Add New Donation
            </Button>
          </div>
          
          {userFoodItems.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {userFoodItems.map(item => (
                <FoodCard key={item.id} food={item} />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-8">
                <p className="mb-4">You haven't made any donations yet.</p>
                <Button 
                  onClick={() => navigate('/donate')}
                  className="bg-connect-green-500 hover:bg-connect-green-600"
                >
                  Donate Food Now
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        
        <TabsContent value="requests">
          <h2 className="text-xl font-bold mb-4">Incoming Requests</h2>
          
          {incomingRequests.length > 0 ? (
            <div className="space-y-4">
              {incomingRequests.map(request => {
                const foodItem = foodItems.find(item => item.id === request.foodItemId);
                return (
                  <Card key={request.id}>
                    <CardContent className="p-6">
                      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                        <div className="md:col-span-3">
                          <h3 className="font-semibold text-lg">{foodItem?.title}</h3>
                          <p className="text-sm text-connect-light-500">
                            Request from {request.requesterName} • {formatDistanceToNow(new Date(request.createdAt))} ago
                          </p>
                          <p className="mt-2 text-connect-light-700">{request.message}</p>
                          <p className="mt-2">
                            <span className="font-medium">Requested quantity:</span> {request.quantity}
                          </p>
                        </div>
                        <div className="md:col-span-2 flex flex-col justify-center items-end">
                          <div className="flex space-x-2">
                            <Button variant="outline">
                              <MessageSquare className="mr-2 h-4 w-4" />
                              Message
                            </Button>
                            {request.status === 'pending' ? (
                              <Button 
                                className="bg-connect-green-500 hover:bg-connect-green-600"
                                onClick={() => handleApproveRequest(request.id)}
                              >
                                <Check className="mr-2 h-4 w-4" />
                                Approve
                              </Button>
                            ) : (
                              <Button 
                                variant="outline" 
                                className="bg-gray-100 text-gray-700 cursor-not-allowed"
                                disabled
                              >
                                {request.status === 'approved' ? 'Approved' : request.status}
                              </Button>
                            )}
                            {foodItem && (
                              <Button 
                                variant="outline"
                                onClick={() => handleViewDetails(foodItem)}
                              >
                                <Eye className="mr-2 h-4 w-4" />
                                View
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-8">
                <p>You don't have any incoming food requests yet.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </>
  );
  
  const renderReceiverDashboard = () => (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-2xl">{userFoodRequests.length}</CardTitle>
            <CardDescription>Total Food Requests</CardDescription>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-2xl">
              {userFoodRequests.filter(req => req.status === 'approved').length}
            </CardTitle>
            <CardDescription>Approved Requests</CardDescription>
          </CardHeader>
        </Card>
      </div>
      
      <h2 className="text-xl font-bold mb-4">My Food Requests</h2>
      
      {userFoodRequests.length > 0 ? (
        <div className="space-y-4">
          {userFoodRequests.map(request => {
            const foodItem = getRequestedFoodItem(request.id);
            return (
              <Card key={request.id}>
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                    <div className="md:col-span-3">
                      <h3 className="font-semibold text-lg">{foodItem?.title}</h3>
                      <p className="text-sm text-connect-light-500">
                        From {foodItem?.donorName} • {formatDistanceToNow(new Date(request.createdAt))} ago
                      </p>
                      <p className="mt-2">
                        <span className="font-medium">Requested quantity:</span> {request.quantity}
                      </p>
                      <div className="mt-2">
                        <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium 
                          ${request.status === 'approved' ? 'bg-green-100 text-green-800' : 
                          request.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                          request.status === 'rejected' ? 'bg-red-100 text-red-800' : 
                          'bg-gray-100 text-gray-800'}`}>
                          {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                        </span>
                      </div>
                    </div>
                    <div className="md:col-span-2 flex flex-col justify-center items-end">
                      <div className="flex space-x-2">
                        <Button variant="outline">
                          <MessageSquare className="mr-2 h-4 w-4" />
                          Message
                        </Button>
                        {foodItem && (
                          <Button 
                            className="bg-connect-green-500 hover:bg-connect-green-600"
                            onClick={() => handleViewDetails(foodItem)}
                          >
                            <Eye className="mr-2 h-4 w-4" />
                            View Details
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card>
          <CardContent className="text-center py-8">
            <p className="mb-4">You haven't requested any food yet.</p>
            <Button 
              onClick={() => navigate('/request')}
              className="bg-connect-green-500 hover:bg-connect-green-600"
            >
              Find Food Now
            </Button>
          </CardContent>
        </Card>
      )}
    </>
  );
  
  const renderNgoDashboard = () => (
    <>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-2xl">{userFoodItems.length}</CardTitle>
            <CardDescription>Food Donations</CardDescription>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-2xl">{userFoodRequests.length}</CardTitle>
            <CardDescription>Food Requests</CardDescription>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-2xl">{incomingRequests.length}</CardTitle>
            <CardDescription>Incoming Requests</CardDescription>
          </CardHeader>
        </Card>
      </div>
      
      <Tabs defaultValue="listings">
        <TabsList className="mb-6">
          <TabsTrigger value="listings">Food Listings</TabsTrigger>
          <TabsTrigger value="requests">Manage Requests</TabsTrigger>
          <TabsTrigger value="donations">Our Donations</TabsTrigger>
        </TabsList>
        
        <TabsContent value="listings">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">Available Food</h2>
            <Button 
              onClick={() => navigate('/request')}
              className="bg-connect-green-500 hover:bg-connect-green-600"
            >
              Browse All Food
            </Button>
          </div>
          
          {foodItems.filter(item => item.status === 'available').length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {foodItems.filter(item => item.status === 'available').slice(0, 6).map(item => (
                <FoodCard key={item.id} food={item} />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-8">
                <p>No food items available right now.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        
        <TabsContent value="requests">
          <h2 className="text-xl font-bold mb-4">Manage Requests</h2>
          
          {/* For an NGO, we'd show a mix of received and made requests */}
          {incomingRequests.length > 0 || userFoodRequests.length > 0 ? (
            <div className="space-y-6">
              {incomingRequests.length > 0 && (
                <div>
                  <h3 className="text-lg font-medium mb-3">Incoming Requests</h3>
                  <div className="space-y-4">
                    {incomingRequests.map(request => {
                      const foodItem = foodItems.find(item => item.id === request.foodItemId);
                      return (
                        <Card key={request.id}>
                          <CardContent className="p-4">
                            <div className="flex flex-col md:flex-row justify-between">
                              <div>
                                <h4 className="font-semibold">{foodItem?.title}</h4>
                                <p className="text-sm text-connect-light-500">
                                  From {request.requesterName} • {formatDistanceToNow(new Date(request.createdAt))} ago
                                </p>
                              </div>
                              <div className="flex space-x-2 mt-4 md:mt-0">
                                <Button variant="outline" size="sm">Message</Button>
                                <Button size="sm" className="bg-connect-green-500 hover:bg-connect-green-600">Approve</Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </div>
              )}
              
              {userFoodRequests.length > 0 && (
                <div>
                  <h3 className="text-lg font-medium mb-3">Outgoing Requests</h3>
                  <div className="space-y-4">
                    {userFoodRequests.map(request => {
                      const foodItem = getRequestedFoodItem(request.id);
                      return (
                        <Card key={request.id}>
                          <CardContent className="p-4">
                            <div className="flex flex-col md:flex-row justify-between">
                              <div>
                                <h4 className="font-semibold">{foodItem?.title}</h4>
                                <p className="text-sm text-connect-light-500">
                                  From {foodItem?.donorName} • Status: {request.status}
                                </p>
                              </div>
                              <div className="flex space-x-2 mt-4 md:mt-0">
                                <Button variant="outline" size="sm">Message</Button>
                                <Button size="sm" className="bg-connect-green-500 hover:bg-connect-green-600">View Details</Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-8">
                <p>No active requests to manage.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        
        <TabsContent value="donations">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">Our Donations</h2>
            <Button 
              onClick={() => navigate('/donate')}
              className="bg-connect-green-500 hover:bg-connect-green-600"
            >
              Add New Donation
            </Button>
          </div>
          
          {userFoodItems.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {userFoodItems.map(item => (
                <FoodCard key={item.id} food={item} />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-8">
                <p className="mb-4">Your organization hasn't made any donations yet.</p>
                <Button 
                  onClick={() => navigate('/donate')}
                  className="bg-connect-green-500 hover:bg-connect-green-600"
                >
                  Donate Food Now
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </>
  );
  
  return (
    <div className="connect-container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-connect-light-900">Welcome, {currentUser.name}</h1>
        <p className="text-connect-light-600">
          {currentUser.role === 'donor' ? 'Manage your food donations and requests' : 
           currentUser.role === 'receiver' ? 'Find available food and manage your requests' :
           "Manage your organization's food connections"}
        </p>
      </div>
      
      {currentUser.role === 'donor' && renderDonorDashboard()}
      {currentUser.role === 'receiver' && renderReceiverDashboard()}
      {currentUser.role === 'ngo' && renderNgoDashboard()}
      
      <FoodDetailsModal 
        food={selectedFood}
        isOpen={detailsModalOpen}
        onClose={() => setDetailsModalOpen(false)}
      />
    </div>
  );
};

export default Dashboard;
