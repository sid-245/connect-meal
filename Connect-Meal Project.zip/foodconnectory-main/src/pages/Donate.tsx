
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useApp } from '@/context/AppContext';
import { useToast } from '@/hooks/use-toast';
import DonationForm from '@/components/donate/DonationForm';
import InfoPanels from '@/components/donate/InfoPanels';

const Donate = () => {
  const { currentUser, addFoodItem } = useApp();
  const { toast } = useToast();
  const navigate = useNavigate();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [quantity, setQuantity] = useState('');
  const [address, setAddress] = useState(currentUser?.address || '');
  const [city, setCity] = useState('');
  const [expiryHours, setExpiryHours] = useState('24');
  const [temperature, setTemperature] = useState<'hot' | 'cold' | 'frozen' | 'room-temperature'>('room-temperature');
  const [categories, setCategories] = useState<string[]>([]);
  const [dietaryInfo, setDietaryInfo] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [coordinates, setCoordinates] = useState<{lat: number, lng: number} | null>(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          console.log("Got geolocation:", {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
          setCoordinates({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.log("Geolocation error:", error);
          setCoordinates({
            lat: 40.7128,
            lng: -74.0060,
          });
        }
      );
    } else {
      setCoordinates({
        lat: 40.7128,
        lng: -74.0060,
      });
    }
  }, []);

  const handleCategoryChange = (id: string) => {
    setCategories(prev => 
      prev.includes(id) 
        ? prev.filter(c => c !== id) 
        : [...prev, id]
    );
  };

  const handleDietaryChange = (id: string) => {
    setDietaryInfo(prev => 
      prev.includes(id) 
        ? prev.filter(d => d !== id) 
        : [...prev, id]
    );
  };

  const handleImageChange = (file: File | null, preview: string | null) => {
    setImageFile(file);
    setImagePreview(preview);
  };

  const handleLocationChange = (lat: number, lng: number) => {
    console.log("Location change in Donate.tsx:", { lat, lng });
    setCoordinates({ lat, lng });
  };

  const handleAddressChange = (newAddress: string) => {
    console.log("Address change in Donate.tsx:", newAddress);
    setAddress(newAddress);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (!currentUser) {
        toast({
          title: 'Authentication required',
          description: 'Please log in to donate food',
          variant: 'destructive',
        });
        navigate('/login');
        return;
      }

      if (!address.trim()) {
        toast({
          title: 'Address required',
          description: 'Please enter a pickup address',
          variant: 'destructive',
        });
        setIsLoading(false);
        return;
      }

      if (!city.trim()) {
        toast({
          title: 'City required',
          description: 'Please enter a city',
          variant: 'destructive',
        });
        setIsLoading(false);
        return;
      }

      if (!coordinates) {
        toast({
          title: 'Location required',
          description: 'Please locate your address on the map',
          variant: 'destructive',
        });
        setIsLoading(false);
        return;
      }

      const expiryDate = new Date();
      expiryDate.setHours(expiryDate.getHours() + parseInt(expiryHours));

      const categoryOptions = [
        { id: 'prepared-food', label: 'Prepared Food' },
        { id: 'produce', label: 'Produce' },
        { id: 'bakery', label: 'Bakery' },
        { id: 'canned-goods', label: 'Canned Goods' },
        { id: 'dairy', label: 'Dairy' },
      ];
      
      const dietaryOptions = [
        { id: 'vegan', label: 'Vegan' },
        { id: 'vegetarian', label: 'Vegetarian' },
        { id: 'gluten-free', label: 'Gluten Free' },
        { id: 'dairy-free', label: 'Dairy Free' },
        { id: 'nut-free', label: 'Nut Free' },
      ];

      console.log("Submitting donation with coordinates:", coordinates);
      console.log("Submitting donation with address:", address);
      console.log("Submitting donation with city:", city);

      const newFood = addFoodItem({
        title,
        description,
        quantity,
        expiryDate: expiryDate.toISOString(),
        status: 'available',
        location: {
          address,
          city,
          coordinates
        },
        donorId: currentUser.id,
        temperature,
        categories: categoryOptions
          .filter(cat => categories.includes(cat.id))
          .map(cat => cat.label),
        dietaryInfo: dietaryOptions
          .filter(diet => dietaryInfo.includes(diet.id))
          .map(diet => diet.label),
        imageUrl: imagePreview || 'https://images.unsplash.com/photo-1498579485796-98be3abc076e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
      });

      toast({
        title: 'Food listed successfully',
        description: 'Your donation has been added to the available food listings',
        variant: 'default',
      });

      navigate('/dashboard');
    } catch (error) {
      toast({
        title: 'Error listing food',
        description: error instanceof Error ? error.message : 'Something went wrong',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="connect-container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-connect-light-900">Donate Food</h1>
        <p className="text-connect-light-600">
          Share your surplus food with those who need it
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Food Donation Details</CardTitle>
            </CardHeader>
            <CardContent>
              <DonationForm
                title={title}
                setTitle={setTitle}
                description={description}
                setDescription={setDescription}
                quantity={quantity}
                setQuantity={setQuantity}
                address={address}
                setAddress={setAddress}
                city={city}
                setCity={setCity}
                expiryHours={expiryHours}
                setExpiryHours={setExpiryHours}
                temperature={temperature}
                setTemperature={setTemperature}
                categories={categories}
                handleCategoryChange={handleCategoryChange}
                dietaryInfo={dietaryInfo}
                handleDietaryChange={handleDietaryChange}
                imagePreview={imagePreview}
                handleImageChange={handleImageChange}
                coordinates={coordinates}
                handleLocationChange={handleLocationChange}
                isLoading={isLoading}
                onSubmit={handleSubmit}
              />
            </CardContent>
          </Card>
        </div>
        
        <div>
          <InfoPanels />
        </div>
      </div>
    </div>
  );
};

export default Donate;
