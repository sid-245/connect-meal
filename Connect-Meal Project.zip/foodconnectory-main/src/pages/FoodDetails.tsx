import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CalendarDays, MapPin, Thermometer, AlertCircle, Tag, Clock, User, Navigation } from 'lucide-react';
import { format } from 'date-fns';
import { FoodItem } from '@/types';
import RequestFoodButton from '@/components/RequestFoodButton';
import DonationMap from '@/components/tracking/DonationMap';

const FoodDetails = () => {
  const { id } = useParams<{ id: string }>();
  const { foodItems, currentUser } = useApp();
  const [food, setFood] = useState<FoodItem | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (id) {
      const foundFood = foodItems.find(item => item.id === id);
      if (foundFood) {
        setFood(foundFood);
      } else {
        setError('Food item not found');
      }
    } else {
      setError('Invalid food item ID');
    }
    setIsLoading(false);
  }, [id, foodItems]);

  const getStatusBadgeColor = (status: string) => {
    switch(status) {
      case 'available':
        return 'bg-green-500';
      case 'reserved':
        return 'bg-yellow-500';
      case 'completed':
        return 'bg-blue-500';
      case 'expired':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getPickupStatusText = (status?: string) => {
    switch(status) {
      case 'pending':
        return 'Pending Pickup';
      case 'in_transit':
        return 'In Transit';
      case 'delivered':
        return 'Delivered';
      default:
        return 'Not Set';
    }
  };

  const getPickupStatusColor = (status?: string) => {
    switch(status) {
      case 'pending':
        return 'bg-yellow-500';
      case 'in_transit':
        return 'bg-blue-500';
      case 'delivered':
        return 'bg-green-500';
      default:
        return 'bg-gray-500';
    }
  };

  if (isLoading) {
    return <div className="connect-container py-12 text-center">Loading...</div>;
  }

  if (error || !food) {
    return (
      <div className="connect-container py-12">
        <Card>
          <CardHeader>
            <CardTitle className="text-center text-red-500">Error</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            {error || 'Food item not found'}
          </CardContent>
        </Card>
      </div>
    );
  }

  const isExpiringSoon = new Date(food.expiryDate).getTime() - Date.now() < 24 * 60 * 60 * 1000; // 24 hours
  const isOwnDonation = currentUser && currentUser.id === food.donorId;
  
  return (
    <div className="connect-container py-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Food Image */}
        <div className="md:col-span-1">
          <div className="w-full h-64 md:h-full rounded-lg overflow-hidden bg-gray-100">
            {food.imageUrl ? (
              <img src={food.imageUrl} alt={food.title} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gray-200">
                <span className="text-gray-400">No image available</span>
              </div>
            )}
          </div>
          
          <div className="mt-4 grid grid-cols-1 gap-4">
            {!isOwnDonation && food.status === 'available' && (
              <RequestFoodButton food={food} />
            )}
            
            {food.pickupStatus && food.pickupStatus !== 'pending' && (
              <Link to={`/track/${food.id}`} className="w-full">
                <Button variant="outline" className="w-full">
                  <Navigation className="mr-2 h-4 w-4" />
                  Track Donation
                </Button>
              </Link>
            )}
          </div>
        </div>
        
        {/* Food Details */}
        <div className="md:col-span-2">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-2xl">{food.title}</CardTitle>
                  <CardDescription>Donated by {food.donorName}</CardDescription>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <Badge className={getStatusBadgeColor(food.status)}>
                    {food.status.charAt(0).toUpperCase() + food.status.slice(1)}
                  </Badge>
                  
                  {food.pickupStatus && (
                    <Badge className={getPickupStatusColor(food.pickupStatus)}>
                      {getPickupStatusText(food.pickupStatus)}
                    </Badge>
                  )}
                </div>
              </div>
            </CardHeader>
            
            <CardContent>
              <div className="prose max-w-none">
                <p>{food.description}</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-connect-light-500" />
                  <div>
                    <p className="text-sm font-medium">Posted</p>
                    <p className="text-sm text-connect-light-600">{format(new Date(food.createdAt), 'PPp')}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <CalendarDays className="h-5 w-5 text-connect-light-500" />
                  <div>
                    <p className="text-sm font-medium">Expires</p>
                    <p className={`text-sm ${isExpiringSoon ? 'text-red-500 font-medium' : 'text-connect-light-600'}`}>
                      {format(new Date(food.expiryDate), 'PPp')}
                      {isExpiringSoon && ' (Soon!)'}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-connect-light-500" />
                  <div>
                    <p className="text-sm font-medium">Location</p>
                    <p className="text-sm text-connect-light-600">{food.location.address}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <User className="h-5 w-5 text-connect-light-500" />
                  <div>
                    <p className="text-sm font-medium">Quantity</p>
                    <p className="text-sm text-connect-light-600">{food.quantity}</p>
                  </div>
                </div>
                
                {food.temperature && (
                  <div className="flex items-center gap-2">
                    <Thermometer className="h-5 w-5 text-connect-light-500" />
                    <div>
                      <p className="text-sm font-medium">Temperature</p>
                      <p className="text-sm text-connect-light-600">{food.temperature.replace('-', ' ')}</p>
                    </div>
                  </div>
                )}
                
                {food.dietaryInfo && food.dietaryInfo.length > 0 && (
                  <div className="flex items-center gap-2">
                    <AlertCircle className="h-5 w-5 text-connect-light-500" />
                    <div>
                      <p className="text-sm font-medium">Dietary Info</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {food.dietaryInfo.map((info, idx) => (
                          <Badge key={idx} variant="outline">{info}</Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
                
                {food.categories && food.categories.length > 0 && (
                  <div className="flex items-center gap-2">
                    <Tag className="h-5 w-5 text-connect-light-500" />
                    <div>
                      <p className="text-sm font-medium">Categories</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {food.categories.map((category, idx) => (
                          <Badge key={idx} variant="secondary">{category}</Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
              
              {food.location.coordinates && (
                <div className="mt-6">
                  <h3 className="text-lg font-semibold mb-3">Location</h3>
                  <div className="h-60 w-full rounded-lg overflow-hidden">
                    <DonationMap donation={food} isInteractive={false} />
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default FoodDetails;
