
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useApp } from '@/context/AppContext';
import FoodCard from '@/components/FoodCard';
import { Heart, Users, UtensilsCrossed } from 'lucide-react';

const Index = () => {
  const { foodItems } = useApp();
  const availableFoodItems = foodItems.filter(item => item.status === 'available');

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-connect-green-50 to-connect-orange-50 py-16 px-4 sm:px-6 lg:px-8">
        <div className="connect-container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
            <div className="flex flex-col space-y-6">
              <h1 className="text-4xl md:text-5xl font-bold text-connect-green-800 leading-tight">
                Where extra food <span className="text-connect-orange-500">finds a purpose</span>
              </h1>
              <p className="text-lg text-connect-light-600 max-w-md">
                Connect surplus food with those who need it most. Join our community to reduce food waste and fight hunger.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 pt-2">
                <Link to="/donate">
                  <Button className="w-full sm:w-auto bg-connect-green-500 hover:bg-connect-green-600 text-white">
                    Donate Food
                  </Button>
                </Link>
                <Link to="/request">
                  <Button variant="outline" className="w-full sm:w-auto border-connect-orange-500 text-connect-orange-500 hover:bg-connect-orange-50">
                    Request Food
                  </Button>
                </Link>
              </div>
            </div>
            <div className="hidden md:block">
              <img 
                src="https://images.unsplash.com/photo-1488459716781-31db52582fe9?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="Fresh food being shared" 
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="connect-container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-connect-light-900">How ConnectMeal Works</h2>
            <p className="mt-4 text-lg text-connect-light-600 max-w-2xl mx-auto">
              A simple three-step process to connect surplus food with people in need
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-connect-green-50 rounded-lg p-6 text-center card-hover">
              <div className="w-16 h-16 bg-connect-green-100 rounded-full flex items-center justify-center mx-auto">
                <span className="text-connect-green-500 text-2xl font-bold">1</span>
              </div>
              <h3 className="mt-4 text-xl font-semibold text-connect-light-900">List Your Surplus Food</h3>
              <p className="mt-2 text-connect-light-600">
                Restaurants, cafes, event organizers, and individuals can easily list food that would otherwise go to waste.
              </p>
            </div>
            
            <div className="bg-connect-orange-50 rounded-lg p-6 text-center card-hover">
              <div className="w-16 h-16 bg-connect-orange-100 rounded-full flex items-center justify-center mx-auto">
                <span className="text-connect-orange-500 text-2xl font-bold">2</span>
              </div>
              <h3 className="mt-4 text-xl font-semibold text-connect-light-900">Connect with Recipients</h3>
              <p className="mt-2 text-connect-light-600">
                Individuals, food banks, and community organizations can discover and request available food in their area.
              </p>
            </div>
            
            <div className="bg-connect-light-50 rounded-lg p-6 text-center card-hover">
              <div className="w-16 h-16 bg-connect-light-100 rounded-full flex items-center justify-center mx-auto">
                <span className="text-connect-light-500 text-2xl font-bold">3</span>
              </div>
              <h3 className="mt-4 text-xl font-semibold text-connect-light-900">Safely Share Food</h3>
              <p className="mt-2 text-connect-light-600">
                Coordinate the pickup or delivery of food, following our food safety guidelines to ensure everything is shared responsibly.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Our Mission Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-connect-green-500 to-connect-green-600 text-white">
        <div className="connect-container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold">Our Mission</h2>
            <p className="mt-4 text-lg text-connect-green-100 max-w-2xl mx-auto">
              We're building a world where no good food goes to waste and everyone has access to nutritious meals
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-center card-hover">
              <div className="mb-4 flex justify-center">
                <Heart className="w-12 h-12 text-connect-orange-300" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Combat Food Waste</h3>
              <p className="text-connect-green-100">
                Reducing the 1.3 billion tons of food wasted globally each year by connecting excess food with those who need it.
              </p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-center card-hover">
              <div className="mb-4 flex justify-center">
                <Users className="w-12 h-12 text-connect-orange-300" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Support Communities</h3>
              <p className="text-connect-green-100">
                Building stronger local communities through food sharing and reducing hunger among vulnerable populations.
              </p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-center card-hover">
              <div className="mb-4 flex justify-center">
                <UtensilsCrossed className="w-12 h-12 text-connect-orange-300" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Food Security</h3>
              <p className="text-connect-green-100">
                Ensuring more people have reliable access to nutritious meals by creating direct connections between donors and recipients.
              </p>
            </div>
          </div>
          
          <div>
            <Link to="/register" className="inline-block">
              <Button className="bg-connect-orange-500 hover:bg-connect-orange-600 text-white border-none">
                Join Our Community
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
