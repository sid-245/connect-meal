
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { useApp } from '@/context/AppContext';
import { useToast } from '@/hooks/use-toast';
import Logo from '@/components/Logo';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login, users } = useApp();
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      await login(email, password);
      toast({
        title: 'Login successful',
        description: 'You have been logged in to your account',
        variant: 'default',
      });
      navigate('/dashboard');
    } catch (error) {
      toast({
        title: 'Login failed',
        description: error instanceof Error ? error.message : 'Something went wrong',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  // For demo purposes, provide login shortcuts
  const demoLogin = (userType: 'donor' | 'receiver' | 'ngo') => {
    let demoEmail = '';
    switch (userType) {
      case 'donor':
        demoEmail = 'jane@example.com';
        break;
      case 'receiver':
        demoEmail = 'john@example.com';
        break;
      case 'ngo':
        demoEmail = 'contact@foodforall.org';
        break;
    }
    
    setEmail(demoEmail);
    setPassword('password');
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-connect-light-50 p-4">
      <div className="w-full max-w-md">
        <div className="mb-6 text-center">
          <Link to="/" className="inline-flex items-center">
            <Logo />
            <span className="ml-2 text-2xl font-bold text-connect-green-600">ConnectMeal</span>
          </Link>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-center">Log in to your account</CardTitle>
            <CardDescription className="text-center">
              Enter your email and password to access your account
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Password</Label>
                  <a href="#" className="text-sm text-connect-green-600 hover:text-connect-green-700">
                    Forgot password?
                  </a>
                </div>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              <Button 
                type="submit" 
                className="w-full bg-connect-green-500 hover:bg-connect-green-600 text-white"
                disabled={isLoading}
              >
                {isLoading ? 'Logging in...' : 'Log in'}
              </Button>
            </form>

            {users.length <= 3 && (
              <div className="mt-6">
                <p className="text-center text-sm text-connect-light-500 mb-4">For demo purposes, you can login as:</p>
                <div className="grid grid-cols-3 gap-2">
                  <Button variant="outline" size="sm" onClick={() => demoLogin('donor')}>
                    Donor
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => demoLogin('receiver')}>
                    Receiver
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => demoLogin('ngo')}>
                    NGO
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
          <CardFooter>
            <p className="text-center w-full text-sm text-connect-light-600">
              Don't have an account?{' '}
              <Link to="/register" className="text-connect-green-600 hover:text-connect-green-700 font-medium">
                Sign up
              </Link>
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default Login;
