
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle2, XCircle, Clock, AlertCircle, PhoneCall } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

const Profile = () => {
  const { currentUser, logout, setCurrentUser } = useApp();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  // State for form fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  
  // Initialize form with user data
  useEffect(() => {
    if (currentUser) {
      setName(currentUser.name || '');
      setEmail(currentUser.email || '');
      setPhone(currentUser.phone || '');
      setAddress(currentUser.address || '');
    }
  }, [currentUser]);
  
  // Redirect to login if not authenticated
  useEffect(() => {
    if (!currentUser) {
      navigate('/login');
    }
  }, [currentUser, navigate]);
  
  if (!currentUser) {
    return null; // Handled by the redirect
  }
  
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };
  
  const handleLogout = () => {
    logout();
    navigate('/');
  };
  
  const handleSaveChanges = () => {
    setIsSaving(true);
    
    // Simulate a small delay for API call
    setTimeout(() => {
      // Update the user data in context
      if (currentUser) {
        const updatedUser = {
          ...currentUser,
          name,
          phone,
          address
        };
        
        setCurrentUser(updatedUser);
        
        toast({
          title: "Profile Updated",
          description: "Your profile information has been saved successfully.",
        });
      }
      
      setIsSaving(false);
    }, 500);
  };
  
  const renderStatusIcon = (isVerified: boolean | undefined) => {
    if (isVerified === true) {
      return <CheckCircle2 className="h-5 w-5 text-connect-green-500" />;
    } else if (isVerified === false) {
      return <XCircle className="h-5 w-5 text-connect-orange-500" />;
    }
    return <Clock className="h-5 w-5 text-connect-light-500" />;
  };
  
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString(undefined, { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };
  
  return (
    <div className="connect-container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-connect-light-900">My Profile</h1>
        <p className="text-connect-light-600">
          Manage your account settings and preferences
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Profile Summary Card */}
        <div className="md:col-span-1">
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col items-center">
                <Avatar className="h-24 w-24 mb-4">
                  <AvatarImage src={currentUser.avatar} alt={currentUser.name} />
                  <AvatarFallback className="text-2xl">{getInitials(currentUser.name)}</AvatarFallback>
                </Avatar>
                
                <h2 className="text-xl font-semibold">{currentUser.name}</h2>
                <p className="text-connect-light-500">{currentUser.email}</p>
                
                <div className="mt-2">
                  <Badge className={`
                    ${currentUser.role === 'donor' ? 'bg-connect-green-500' : ''}
                    ${currentUser.role === 'receiver' ? 'bg-connect-orange-500' : ''}
                    ${currentUser.role === 'ngo' ? 'bg-connect-light-500' : ''}
                  `}>
                    {currentUser.role === 'donor' ? 'Food Donor' : 
                     currentUser.role === 'receiver' ? 'Food Recipient' : 
                     'NGO/Organization'}
                  </Badge>
                </div>
                
                <Separator className="my-6" />
                
                <Button
                  onClick={handleLogout}
                  variant="outline"
                  className="w-full"
                >
                  Log Out
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Account Status</CardTitle>
              <CardDescription>Your current verification status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-connect-light-500">Member since</span>
                  <span className="font-medium">{formatDate(currentUser.createdAt)}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-connect-light-500">Phone verification</span>
                  <div className="flex items-center">
                    {renderStatusIcon(currentUser.phoneVerified)}
                    <span className={`ml-2 ${
                      currentUser.phoneVerified 
                        ? 'text-connect-green-500' 
                        : 'text-connect-orange-500'
                    }`}>
                      {currentUser.phoneVerified ? 'Verified' : 'Not Verified'}
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-connect-light-500">Role status</span>
                  <Badge className={`
                    ${currentUser.role === 'donor' ? 'bg-connect-green-500' : ''}
                    ${currentUser.role === 'receiver' ? 'bg-connect-orange-500' : ''}
                    ${currentUser.role === 'ngo' ? 'bg-connect-light-500' : ''}
                  `}>
                    {currentUser.role === 'donor' ? 'Food Donor' : 
                     currentUser.role === 'receiver' ? 'Food Recipient' : 
                     currentUser.role === 'ngo' ? 'NGO/Organization' : 'Admin'}
                  </Badge>
                </div>
                
                {!currentUser.phoneVerified && (
                  <Alert className="mt-2 bg-connect-orange-50 border-connect-orange-200">
                    <AlertCircle className="h-4 w-4 text-connect-orange-500" />
                    <AlertDescription className="text-connect-orange-700">
                      Phone verification is required to access all features
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            </CardContent>
            {!currentUser.phoneVerified && (
              <CardFooter className="flex justify-center">
                <Button size="sm" className="flex items-center gap-2 bg-connect-green-500 hover:bg-connect-green-600">
                  <PhoneCall className="h-4 w-4" />
                  Verify Phone Number
                </Button>
              </CardFooter>
            )}
          </Card>
        </div>
        
        {/* Profile Tabs */}
        <div className="md:col-span-3">
          <Tabs defaultValue="profile">
            <TabsList className="mb-6">
              <TabsTrigger value="profile">Profile Information</TabsTrigger>
              <TabsTrigger value="preferences">Preferences</TabsTrigger>
              <TabsTrigger value="notifications">Notifications</TabsTrigger>
            </TabsList>
            
            <TabsContent value="profile">
              <Card>
                <CardHeader>
                  <CardTitle>Profile Information</CardTitle>
                  <CardDescription>
                    Update your account details and contact information
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form className="space-y-6" onSubmit={(e) => {
                    e.preventDefault();
                    handleSaveChanges();
                  }}>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="name">Full Name</Label>
                        <Input
                          id="name"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          disabled
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input
                          id="phone"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="Enter your phone number"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="role">Account Type</Label>
                        <Input
                          id="role"
                          value={currentUser.role === 'donor' ? 'Food Donor' : 
                                 currentUser.role === 'receiver' ? 'Food Recipient' : 
                                 'NGO/Organization'}
                          disabled
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="address">Address</Label>
                      <Input
                        id="address"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        placeholder="Enter your address"
                      />
                    </div>
                    
                    <Button 
                      type="submit"
                      className="bg-connect-green-500 hover:bg-connect-green-600"
                      disabled={isSaving}
                    >
                      {isSaving ? 'Saving...' : 'Save Changes'}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="preferences">
              <Card>
                <CardHeader>
                  <CardTitle>Preferences</CardTitle>
                  <CardDescription>
                    Customize your experience and notification settings
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-connect-light-500">Preference settings will be available soon.</p>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="notifications">
              <Card>
                <CardHeader>
                  <CardTitle>Notification Settings</CardTitle>
                  <CardDescription>
                    Control how and when you receive notifications
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-connect-light-500">Notification settings will be available soon.</p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default Profile;
