import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useApp } from '@/context/AppContext';
import { useToast } from '@/hooks/use-toast';
import { UserRole } from '@/types';
import Logo from '@/components/Logo';
import { 
  InputOTP, 
  InputOTPGroup, 
  InputOTPSlot 
} from '@/components/ui/input-otp';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Info, Check, X } from 'lucide-react';

const Register = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState<UserRole>('receiver');
  const [isLoading, setIsLoading] = useState(false);
  const [phone, setPhone] = useState('');
  const [showOTPInput, setShowOTPInput] = useState(false);
  const [otpValue, setOTPValue] = useState('');
  const [generatedOTP, setGeneratedOTP] = useState('');
  const [verificationStatus, setVerificationStatus] = useState<'pending' | 'success' | 'error'>('pending');
  
  const { register } = useApp();
  const { toast } = useToast();
  const navigate = useNavigate();

  const generateOTP = () => {
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOTP(otp);
    return otp;
  };

  const handleSendOTP = () => {
    const phoneRegex = /^\+?[0-9]{10,15}$/;
    if (!phoneRegex.test(phone)) {
      toast({
        title: 'Invalid phone number',
        description: 'Please enter a valid phone number',
        variant: 'destructive',
      });
      return;
    }

    const otp = generateOTP();
    setShowOTPInput(true);
    
    toast({
      title: 'OTP Sent!',
      description: `Your OTP is: ${otp}`,
      variant: 'default',
    });
  };

  const handleVerifyOTP = () => {
    if (otpValue === generatedOTP) {
      setVerificationStatus('success');
      toast({
        title: 'Phone verified successfully',
        description: 'Your phone number has been verified',
        variant: 'default',
      });
    } else {
      setVerificationStatus('error');
      toast({
        title: 'Verification failed',
        description: 'The OTP you entered is incorrect',
        variant: 'destructive',
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (password !== confirmPassword) {
      toast({
        title: 'Passwords do not match',
        description: 'Please make sure your passwords match',
        variant: 'destructive',
      });
      return;
    }
    
    if (password.length < 6) {
      toast({
        title: 'Password too short',
        description: 'Password must be at least 6 characters long',
        variant: 'destructive',
      });
      return;
    }
    
    if (!phone || verificationStatus !== 'success') {
      toast({
        title: 'Phone verification required',
        description: 'Please verify your phone number before registering',
        variant: 'destructive',
      });
      return;
    }
    
    setIsLoading(true);

    try {
      await register({ 
        name, 
        email, 
        role,
        phone,
        phoneVerified: true
      }, password);
      toast({
        title: 'Registration successful',
        description: 'Your account has been created',
        variant: 'default',
      });
      navigate('/dashboard');
    } catch (error) {
      toast({
        title: 'Registration failed',
        description: error instanceof Error ? error.message : 'Something went wrong',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-connect-light-50 p-4">
      <div className="w-full max-w-md">
        <div className="mb-6 text-center">
          <Link to="/" className="inline-flex items-center">
            <Logo />
            <span className="ml-2 text-2xl font-bold text-connect-green-600">ConnectMeal</span>
          </Link>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-center">Create an account</CardTitle>
            <CardDescription className="text-center">
              Join ConnectMeal to start donating or requesting food
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  type="text"
                  placeholder="Your Name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <div className="flex space-x-2">
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+1234567890"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                    disabled={verificationStatus === 'success'}
                    className={verificationStatus === 'success' ? "bg-gray-100" : ""}
                  />
                  <Button 
                    type="button" 
                    onClick={handleSendOTP}
                    disabled={!phone || verificationStatus === 'success'}
                    variant="outline"
                  >
                    {verificationStatus === 'success' ? 'Verified' : 'Verify'}
                  </Button>
                </div>
              </div>
              
              {showOTPInput && verificationStatus !== 'success' && (
                <div className="space-y-2">
                  <Label htmlFor="otp">Enter OTP sent to your phone</Label>
                  <div className="flex flex-col space-y-3">
                    <InputOTP maxLength={6} value={otpValue} onChange={setOTPValue}>
                      <InputOTPGroup>
                        <InputOTPSlot index={0} />
                        <InputOTPSlot index={1} />
                        <InputOTPSlot index={2} />
                        <InputOTPSlot index={3} />
                        <InputOTPSlot index={4} />
                        <InputOTPSlot index={5} />
                      </InputOTPGroup>
                    </InputOTP>
                    <Button 
                      type="button" 
                      onClick={handleVerifyOTP}
                      disabled={otpValue.length !== 6}
                      className="bg-connect-green-500 hover:bg-connect-green-600 text-white"
                    >
                      Verify OTP
                    </Button>
                  </div>
                </div>
              )}
              
              {verificationStatus === 'success' && (
                <Alert className="bg-connect-green-50 border-connect-green-200 text-connect-green-700">
                  <Check className="h-4 w-4" />
                  <AlertTitle>Phone Verified</AlertTitle>
                  <AlertDescription>Your phone number has been verified successfully.</AlertDescription>
                </Alert>
              )}
              
              {verificationStatus === 'error' && (
                <Alert className="bg-red-50 border-red-200 text-red-700">
                  <X className="h-4 w-4" />
                  <AlertTitle>Verification Failed</AlertTitle>
                  <AlertDescription>The OTP entered is incorrect. Please try again.</AlertDescription>
                </Alert>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm Password</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label>I want to:</Label>
                <RadioGroup value={role} onValueChange={(value) => setRole(value as UserRole)} className="grid grid-cols-1 gap-2">
                  <div className="flex items-center space-x-2 rounded-md border p-3">
                    <RadioGroupItem value="donor" id="donor" />
                    <Label htmlFor="donor" className="flex-grow cursor-pointer">Donate Food</Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-md border p-3">
                    <RadioGroupItem value="receiver" id="receiver" />
                    <Label htmlFor="receiver" className="flex-grow cursor-pointer">Request Food</Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-md border p-3">
                    <RadioGroupItem value="ngo" id="ngo" />
                    <Label htmlFor="ngo" className="flex-grow cursor-pointer">Represent an NGO or Food Bank</Label>
                  </div>
                </RadioGroup>
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-connect-green-500 hover:bg-connect-green-600 text-white"
                disabled={isLoading || verificationStatus !== 'success'}
              >
                {isLoading ? 'Creating account...' : 'Create account'}
              </Button>
            </form>
          </CardContent>
          <CardFooter>
            <p className="text-center w-full text-sm text-connect-light-600">
              Already have an account?{' '}
              <Link to="/login" className="text-connect-green-600 hover:text-connect-green-700 font-medium">
                Log in
              </Link>
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default Register;
