
import React, { useState, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import FoodCard from '@/components/FoodCard';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Search, MapPin } from 'lucide-react';

const Request = () => {
  const { foodItems, currentUser } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [cityFilter, setCityFilter] = useState<string>('all');
  const [dietaryFilters, setDietaryFilters] = useState<string[]>([]);
  const [availableCities, setAvailableCities] = useState<string[]>([]);
  
  const availableFoodItems = foodItems.filter(item => item.status === 'available');
  
  // Extract unique cities from food items
  useEffect(() => {
    const cities = availableFoodItems
      .map(item => item.location.city)
      .filter((city): city is string => !!city) // Filter out undefined/null cities
      .filter((city, index, self) => self.indexOf(city) === index) // Get unique cities
      .sort();
    
    setAvailableCities(cities);
    
    // If the user has a saved city preference or a current location, try to use that
    if (currentUser?.address) {
      const userCity = currentUser.address.split(',').slice(-2)[0]?.trim();
      if (userCity && cities.includes(userCity)) {
        setCityFilter(userCity);
      }
    }
  }, [availableFoodItems, currentUser]);
  
  const dietaryOptions = [
    { id: 'vegan', label: 'Vegan' },
    { id: 'vegetarian', label: 'Vegetarian' },
    { id: 'gluten-free', label: 'Gluten Free' },
    { id: 'dairy-free', label: 'Dairy Free' },
  ];
  
  const handleDietaryChange = (id: string) => {
    setDietaryFilters(prev => 
      prev.includes(id) 
        ? prev.filter(d => d !== id) 
        : [...prev, id]
    );
  };
  
  const filteredFoodItems = availableFoodItems.filter(item => {
    // Search term filter
    if (searchTerm && !item.title.toLowerCase().includes(searchTerm.toLowerCase()) && 
        !item.description.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    
    // City filter
    if (cityFilter !== 'all' && item.location.city !== cityFilter) {
      return false;
    }
    
    // Category filter
    if (categoryFilter !== 'all' && 
        (!item.categories || !item.categories.some(cat => cat.toLowerCase().includes(categoryFilter.toLowerCase())))) {
      return false;
    }
    
    // Dietary filter
    if (dietaryFilters.length > 0 && 
        (!item.dietaryInfo || !dietaryFilters.every(filter => 
          item.dietaryInfo?.some(diet => diet.toLowerCase().includes(filter.toLowerCase()))
        ))) {
      return false;
    }
    
    return true;
  });
  
  return (
    <div className="connect-container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-connect-light-900">Request Food</h1>
        <p className="text-connect-light-600">
          Find available food donations in your area
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Filters Sidebar */}
        <div className="md:col-span-1">
          <div className="bg-white rounded-lg shadow p-6 sticky top-20">
            <h2 className="text-lg font-semibold mb-4">Filters</h2>
            
            <div className="space-y-6">
              <div>
                <Label className="mb-2 block">City</Label>
                <Select value={cityFilter} onValueChange={setCityFilter}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select city" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Cities</SelectItem>
                    {availableCities.map(city => (
                      <SelectItem key={city} value={city}>
                        {city}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label className="mb-2 block">Category</Label>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="prepared">Prepared Food</SelectItem>
                    <SelectItem value="produce">Produce</SelectItem>
                    <SelectItem value="bakery">Bakery</SelectItem>
                    <SelectItem value="canned">Canned Goods</SelectItem>
                    <SelectItem value="dairy">Dairy</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label className="mb-2 block">Dietary Preferences</Label>
                <div className="space-y-2">
                  {dietaryOptions.map((diet) => (
                    <div key={diet.id} className="flex items-center space-x-2">
                      <Checkbox 
                        id={`diet-${diet.id}`} 
                        checked={dietaryFilters.includes(diet.id)}
                        onCheckedChange={() => handleDietaryChange(diet.id)}
                      />
                      <Label htmlFor={`diet-${diet.id}`}>{diet.label}</Label>
                    </div>
                  ))}
                </div>
              </div>
              
              <Button 
                onClick={() => {
                  setSearchTerm('');
                  setCategoryFilter('all');
                  setCityFilter('all');
                  setDietaryFilters([]);
                }}
                variant="outline" 
                className="w-full"
              >
                Reset Filters
              </Button>
            </div>
          </div>
        </div>
        
        {/* Food Listings */}
        <div className="md:col-span-3">
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-connect-light-500" />
              <Input 
                placeholder="Search for food, e.g., 'sandwich', 'fruit', 'soup'..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          
          {cityFilter !== 'all' && (
            <div className="mb-4 flex items-center text-connect-light-700">
              <MapPin className="w-4 h-4 mr-1" />
              <span>Showing results in {cityFilter}</span>
            </div>
          )}
          
          {filteredFoodItems.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
              {filteredFoodItems.map(item => (
                <FoodCard key={item.id} food={item} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-lg shadow">
              <p className="text-connect-light-500 mb-2">No food items match your search criteria.</p>
              <p className="text-connect-light-700">Try adjusting your filters or check back later for new donations.</p>
              <Button 
                onClick={() => {
                  setSearchTerm('');
                  setCategoryFilter('all');
                  setCityFilter('all');
                  setDietaryFilters([]);
                }}
                variant="outline"
                className="mt-4"
              >
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Request;
