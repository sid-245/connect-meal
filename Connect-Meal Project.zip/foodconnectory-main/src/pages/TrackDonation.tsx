
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useApp } from '@/context/AppContext';
import DonationMap from '@/components/tracking/DonationMap';
import DonationTrackingInfo from '@/components/tracking/DonationTrackingInfo';
import DonationUpdateLocation from '@/components/tracking/DonationUpdateLocation';
import { FoodItem } from '@/types';

const TrackDonation = () => {
  const { id } = useParams<{ id: string }>();
  const { foodItems, updateFoodItem, currentUser } = useApp();
  const [donation, setDonation] = useState<FoodItem | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (id) {
      const foundDonation = foodItems.find(item => item.id === id);
      if (foundDonation) {
        setDonation(foundDonation);
      } else {
        setError('Donation not found');
      }
    } else {
      setError('Invalid donation ID');
    }
    setIsLoading(false);
  }, [id, foodItems]);

  const handleStatusUpdate = (newStatus: 'pending' | 'in_transit' | 'delivered') => {
    if (donation && id) {
      updateFoodItem(id, { pickupStatus: newStatus });
      setDonation({ ...donation, pickupStatus: newStatus });
    }
  };

  const handleLocationUpdate = (lat: number, lng: number) => {
    if (donation && id) {
      const timestamp = new Date().toISOString();
      const newLocation = { lat, lng, timestamp };
      
      // Create or update tracking history
      const trackingHistory = donation.trackingHistory || [];
      const updatedHistory = [...trackingHistory, { lat, lng, timestamp }];
      
      updateFoodItem(id, { 
        currentLocation: newLocation,
        trackingHistory: updatedHistory
      });
      
      setDonation({ 
        ...donation, 
        currentLocation: newLocation,
        trackingHistory: updatedHistory
      });
    }
  };

  if (isLoading) {
    return <div className="flex justify-center items-center h-64">Loading...</div>;
  }

  if (error || !donation) {
    return (
      <div className="connect-container py-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-center text-red-500">Error</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            {error || 'Donation not found'}
          </CardContent>
        </Card>
      </div>
    );
  }

  const canUpdateLocation = currentUser && 
    (currentUser.id === donation.donorId || 
    currentUser.role === 'ngo' || 
    currentUser.role === 'admin');

  const isReceiver = currentUser && currentUser.role === 'receiver';

  return (
    <div className="connect-container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-connect-light-900">
          Track Donation
        </h1>
        <p className="text-connect-light-600">
          Real-time tracking of food donation
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Donation Details</CardTitle>
              <Badge 
                className={`${
                  donation.pickupStatus === 'pending' ? 'bg-yellow-500' : 
                  donation.pickupStatus === 'in_transit' ? 'bg-blue-500' :
                  donation.pickupStatus === 'delivered' ? 'bg-green-500' :
                  'bg-gray-500'
                }`}
              >
                {donation.pickupStatus === 'pending' ? 'Pending Pickup' : 
                 donation.pickupStatus === 'in_transit' ? 'In Transit' :
                 donation.pickupStatus === 'delivered' ? 'Delivered' :
                 'Not Started'}
              </Badge>
            </CardHeader>
            <CardContent>
              <DonationTrackingInfo 
                donation={donation} 
                onStatusUpdate={canUpdateLocation ? handleStatusUpdate : undefined} 
              />
            </CardContent>
          </Card>

          {canUpdateLocation && donation.pickupStatus === 'in_transit' && (
            <Card className="mt-4">
              <CardHeader>
                <CardTitle>Update Location</CardTitle>
              </CardHeader>
              <CardContent>
                <DonationUpdateLocation onLocationUpdate={handleLocationUpdate} />
              </CardContent>
            </Card>
          )}
        </div>

        <div className="md:col-span-2">
          <Card className="h-full">
            <CardHeader>
              <CardTitle>Live Tracking</CardTitle>
            </CardHeader>
            <CardContent className="h-[500px]">
              <DonationMap 
                donation={donation} 
                isInteractive={true} 
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default TrackDonation;
