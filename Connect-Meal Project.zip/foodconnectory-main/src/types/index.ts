
export type UserRole = 'donor' | 'receiver' | 'ngo' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  phone?: string;
  phoneVerified?: boolean;
  address?: string;
  verified: boolean;
  createdAt: string;
  password?: string; // Added for registration functionality
}

export interface FoodItem {
  id: string;
  title: string;
  description: string;
  quantity: string;
  expiryDate: string;
  createdAt: string;
  status: 'available' | 'reserved' | 'completed' | 'expired';
  location: {
    address: string;
    city?: string; // Added city field
    coordinates?: {
      lat: number;
      lng: number;
    }
  };
  donorId: string;
  donorName: string;
  imageUrl?: string;
  dietaryInfo?: string[];
  temperature?: 'hot' | 'cold' | 'frozen' | 'room-temperature';
  categories?: string[];
  pickupStatus?: PickupStatus;
  trackingHistory?: LocationUpdate[];
  currentLocation?: {
    lat: number;
    lng: number;
    timestamp: string;
  };
}

export type PickupStatus = 'pending' | 'in_transit' | 'delivered';

export interface LocationUpdate {
  lat: number;
  lng: number;
  timestamp: string;
}

export interface FoodRequest {
  id: string;
  foodItemId: string;
  requesterId: string;
  requesterName: string;
  status: 'pending' | 'approved' | 'rejected' | 'completed';
  message?: string;
  quantity: string;
  createdAt: string;
  approvedAt?: string; // Added for tracking when the request was approved
}

export interface Notification {
  id: string;
  userId: string;
  message: string;
  read: boolean;
  createdAt: string;
  type: 'donation' | 'request' | 'system' | 'verification';
  relatedItemId?: string;
}
